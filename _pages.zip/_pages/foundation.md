---
title: Foundation
---

* 'mobile first'
* row, column(s), panel
* small, medium, large
* interchange
* media queries 
