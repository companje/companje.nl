---
title: Electronics
---

see [[elektronica]]

=====Capacitors=====
*[[https://www.youtube.com/watch?feature=player_embedded&v=M2tJpEMIkWM|waarom je bij elke chip een klein condensatortje moet plaatsen]]

=====Electronic cars=====
* http://e-volks.com/

=====Soldering=====
* [[https://www.youtube.com/watch?v=7a3dA4r8rxc&feature=youtu.be&t=400|Smart way to solder Kynar wires]]
* [[http://elm-chan.org/docs/wire/wiring_e.html|extreme smd soldering]]
