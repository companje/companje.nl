---
title: iPhone
---

==sleep/wake button problem==
https://ssl.apple.com/nl/support/iphone5-sleepwakebutton/

==battery replacement iphone5==
my serial nr: DNQJWMKBDTWD
https://ssl.apple.com/nl/support/iphone5-battery/

===== Developing for the iPhone =====
*HFSExplorer can be used to extract .dmg files in Windows. Also in [[Linux]]?
