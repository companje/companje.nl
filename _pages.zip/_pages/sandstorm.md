---
title: Sandstorm.io
---

https://sandstorm.io

(Centos 6.6 not supported currently 2015-09-5)

==Install==
  curl https://install.sandstorm.io | bash
