---
title: Cool Cucumbers & HYPE
---
Thursday the 12th of June 2008 at the [[http://eurodusnie.nl/index.php?option=com_eventlist&Itemid=616&func=shcatev1&categid=5|Linkse Kerk]], Leiden (see [[http://maps.google.com/maps?f=q&hl=en&geocode=&q=koppenhinksteeg+2,+leiden,+netherlands&sll=52.159611,4.494452&sspn=0.008793,0.021329&ie=UTF8&ll=52.161731,4.489396&spn=0.008793,0.021329&z=16&iwloc=addr|map]])
open 19h30 - start 20h00
free entrance
more info can be found at [[http://www.coolcucumbers.org/index.php?event=2|CoolCucumbers.org]]
\
\
Cool Cucumbers is a serie of evenings presenting a mix of speakers from many different backgrounds who aim to inform and inspire. Each evening Cool Cucumbers presents a particular theme and is exploring the borders of art, media, technology and science within that theme. Furthermore, Cool Cucumbers tries to stimulate the audience to ask questions and participate in discussions within an informal environment with drinks and toast with cucumber salad!
Bring your friends!
\
[[http://www.coolcucumbers.org/index.php?event=2|CoolCucumbers.org]]  
[[http://mediatechnology.leiden.edu/|MediaTechnology Leiden University]]  
[[http://www.kabk.nl/studierichtingen/as/index/-/en|ArtScience KABK The Hague]]  

(tag>Events Art MediaTech)

~~DISCUSSION~~



(tag>)


~~DISCUSSION~~
