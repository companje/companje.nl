---
title: OpenGL without X
---
* https://en.wikibooks.org/wiki/OpenGL_Programming/Installation/Linux
