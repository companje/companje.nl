---
title: GIF
---
* https://github.com/phw/peek (tip v Peter)
* http://www.cockos.com/licecap/
* [[https://baremetrics.com/blog/gifs-feature-rollout|Step-by-Step: Creating amazing GIFs to announce new features
]]
