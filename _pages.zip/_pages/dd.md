---
title: dd
---


====status====
See status with Ctrl+T

====read 1000 bytes from file====
  dd count=1000 bs=1 if=/Volumes/tijdmachine/zaagsel.rgb > zaagsel-1000bytes.rgb
  
