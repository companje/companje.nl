---
title: Next TOKO about Arduino & GPS
---
Next TOKO is about Arduino (and similar boards) and will be held in Amersfoort on the 6th of June. Here's the program:
\
10.00 - 12.00
'This Is Wiring (and Arduino)' by Maarten Lamers. A crash course on how to get started with Arduino.

12.00 - lunch
demonstration of a mobile GPS application using wiring/arduino, by Maarten

lunch - 16.00
Edwin Dertien developed his own alternative arduino board and builds all kinds of interesting stuff with it. He will present the board and demonstrate a GPS-tracking robot with it.

16.00 - late
Open workshop. Bring your own arduino based invention and show it to others, or start building your own application with some experts being around to help when needed. Basic tools like soldering irons will be available. We'll also have some spare arduino boards lying around. Around 18.00 we'll prepare some food and after dinner we'll go on tinkering until we run out of power.

The workshop is for free, we just ask a contribution to expenses made for food and drinks. Click here for a routedescription. More info on de TOKO can be found here (in Dutch until further notice). Please come if you can, and let us know if you do. Pass this email on to others that might be interested.

Diana, Rick, Harmen


http://www.arduino.cc/
http://www.wiring.org.co/
http://www.maartenlamers.com/ThisIsWiring/


(tag>Events Electronics Tech Projects)


~~DISCUSSION~~
