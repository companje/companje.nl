---
title: =====Continental Drift / Plate Tectonics=====
---
* https://www.youtube.com/watch?v=wJS7hGMr0Ws
