---
title: First person tetris, briljant!
---
Dit is erg leuk! Speel tetris op een hele nieuwe manier. 
Tip: druk tijdens het spel op spatie om je blokje te draaien.
\
http://www.firstpersontetris.com  
\
[[http://www.firstpersontetris.com/|(:blog:first-person-tetris.jpg|)]]

(tag>Fun)


~~DISCUSSION~~
