---
title: Globe4D op de fiets!
---
We zijn nu zo'n vier dagen in India en het is hier super. Het festival is groots opgezet en helemaal georganiseerd door studenten. Zoals je op de foto ziet werkt hier alles iets anders dan bij ons. De kist waarin Globe4D vervoerd is het laatste stukje per fiets bezorgd :-). Binnenkort meer info en filmpjes over de Globe4D India reis.

 
(http://www.companje.nl/wp-content/uploads/2008/02/globe4d-op-de-fiets.jpg)

(tag>)


~~DISCUSSION~~
