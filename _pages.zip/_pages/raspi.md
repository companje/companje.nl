---
title: RaspberryPi
---

====Ease SD Card Setup====
* http://elinux.org/RPi_Easy_SD_Card_Setup

====openFrameworks on Raspberry Pi====
* [[http://openframeworks.cc/setup/raspberrypi/Raspberry-Pi-Getting-Started.html|getting started]]
* [[http://openframeworks.cc/setup/raspberrypi/Raspberry-Pi-Cross-compiling-guide.html|cross compiling]]
* [[http://www.openframeworks.cc/setup/raspberrypi/Raspberry-Pi-DISTCC-guide.html|distcc]]
