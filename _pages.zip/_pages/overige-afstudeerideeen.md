---
title: Overige afstudeerideeen
---

=====Wat wil ik niet=====
*Ik wil geen spelletje maken.

=====evt. begleiders=====
*[[Koert van Mensvoort]]
*[[Maarten Lamers]]
*[[Vincent Icke]] (afhankelijk van onderwerp)
*[[Bas Haring]]

=====Filosofie=====
*[[Filosofie]]: Is het aantal dingen om over te denken eindig? Op een bepaald moment een eindig aantal bestaande/denkbare dingen? Zo ja, dan komt er een tijd dat op internet alle mogelijke gedachten en combi's voorkomen. Alle denkwijzen?

===== Geometrische vormen en tijd =====
*Nieuwe inzichten op het gebruik van geometrische vormen bij het tonen van data over tijd.
**Dynamische data visualiseren op/in 3 dimensionale objecten (kubus, bol, cylinder). En interactie hebben met deze data
*Boek schrijven "De cirkel, de bol en de cylinder voor dummies"
*Nieuw soort kalender of klok
**Dagen zijn aaneengesloten (als bij een standaard tijdlijn). Maar tijd is lineair maar heeft vaste terugkerende momenten. Je wil jaren met elkaar kunnen vergelijken maar ook *maanden, dagen, uren, minuten.
*Kubusvormige spreadsheet. 
**Spreadcube. Tensor, 3D matrix, kubus spreadsheet
*Cilinder als informatiedrager. 
**Het grote voordeel van een cylinder t.o.v. andere tijdweergaven is dat je er 2D overheen kunt tekenen maar dat ie toch oneindig is in twee richtingen. Een vierkant heeft vier zijden waar je tekenvel ophoudt. Een cylinder maar twee. Een bol is helemaal oneindig maar heeft heel vervorming bij de polen. Nadeel van een cylinder is dat je 'm niet aan alle kanten op het zelfde moment kunt bekijken. Tenzij je 'm platslaat. Dan wordt het weer een vierkant.
**Je kunt de straal van de cylinder instellen op uur,dag,week etc. Zo kun je super herhalende patronen vinden.
**"Cylinder as a visual pattern finder"
**Seismograaf
**Cylindrical clock?
**Phonograph cylinder (Edison 1877)
**Rolodex (ronde kaartenbak)
**Foto seismograaf. Apparaat met cilinder, camera erboven. De foto's die genomen worden verschijnen op de rol. Interactie ja/nee?
**Foto's analyseren op een cylinder. Dagen op x-as, uren op y as, op een cilinder.
**Je moet die geplotte data natuurlijk ook plat kunnen tonen. Omvormen van cilinder projectie naar plat
**Cilindric body, Drum, Geometrische vormen, 
**Temporal data on cylinders
**Boekrol
**Zie verwijzingen en foto's Joost Rekvelt

*Quote "I've always been facinated with circular stuff." [http://www.halfbakery.com/idea/Circular_20Scrolling]

*"In 1959, (Jasper) Johns wrote that the following suggestion made by Marcel Duchamp was of particular interest to him: "to reach the Impossibility of sufficient visual memory to transfer from one like object to another the memory imprint.""
*geometric primitive solids which currently are cubes, spheres/ellipsoids, cylinders
*[[Mobius band]]
**Oneindig net als de Mobius band
**Kan de Mobius band gebruikt worden voor het tonen van data?
*My life on a cylinder
*De acties in je leven vastleggen op een cilinder. Net als het naaldje van de seismograaf. In plaats van een grafiekje van een lijntje zou je bijvoorbeeld foto's van momenten. De cilinder moet per dag een keer rond. Met eventueel ook zo'n test-tik. Zodat je 'm ziet verschuiven (kurketrekker achtig).
*Waarom is de stap gemaakt van grammafoon naar cassettebandje en niet naar cilinder? Wordt ie dan te lang?
*[[4D Space]] boek

=====Time Slice achtige dingen=====
*	Live televisiebeelden als data gebruiken en op een rol plotten (net als het naaldje seismograaf). Soort histogram. Naald loopt door zeg maar...
*	Split scan video art, time slices: time/space

=====Fysieke interfaces / hardware / electronica=====
*Levend Ministeck (iets te veel een display project)
*Dubbelklik-trippletap apparaatje
*Hardware hacking
*Kermis grijper& uhm& wat wou ik hier nou weer mee?
*"Electronic Bodies" - The Exhibition. Electronische apparaten ontleed en uitgelegd.
*Phidgets (Physical Widgets)
*Vingerherkinning. Touchpad die herkent met welke vinger je m gebruikt. Zo kun je bijvoorbeeld met je ringvinger scrollen. We hebben tien vingers en we gebruiken iedere vinger nu maar voor een paar vaste toetsen als je blind kunt tikken. Daar kun je meer in kwijt. Bijv. dat ie herkent dat je met je middelvinger de 'o' aanklikt dat ie dan automatisch o-umlaut doet ofzo.
*Oneindige trap van Escher gebruiken met akkoorden.
*Stoplicht idee van [[Maarten Lamers]]. Animaties uploaden naar een stoplicht. Onder het mom van gedragsverandering. Dat fietsers minder snel door rood gaan rijden omdat er wat leuks te zien is. Moonwalkend Ampelmänchen. Er moet we; zoveel % rood inzitten. Gevaren ervan.
*een nieuw soort direct-manipulation device.

=====Persoonlijke collecties=====
*Niet iedereen zal de behoefte voelen. Generatiekloof.
*Hecht jonge generatie meer waarde aan digitale documenten (data)? (Afnemen van afdrukken van fotos)
*Nalatenschap van data
*Erfenis in geld en goederen moet verdeeld worden. Data kan gedupliceerd worden.
*Er zijn nu nog geen bejaarden met 80 jaar computer geschiedenis (sporen) op hun HD kerfstok. Straks wel...
*Wat gebeurt er met al die data als iemand overlijd of het traject dat daar aan vooraf gaat.
*Is er A-life na de dood? Oftewel kan jou identiteit / gedrag nagemaakt worden. Door blijven bloggen bijvoorbeeld&
*	Digitaal automatisch voortlevend never ending testament.
*	Bloggen vanuit je doodskist
*	Meme fossils (term bestaat nog niet op google)
*	Digital Archeology
*	The unborn meme
*	Making backups is like flossing - everyone knows it's important, but few devote enough thought or energy to it. (2003, Business 2.0 magazine)
*	Digitale rariteitenkabinetten
*	Museum met digitale fossielen
*	Wie schrijft die blijft
*	I write, therefore I am: As a variation on a famous statement by the 17th-century French philosopher Descartes, I would like to say: "I write, therefore I am". More and more, I come to the realization that the act of writing is one of the key ways of expressing myself. I started to write a diary when I was 14. Since February 1995, I also keep an online diary till April 2007. I am also an irregular poster to Slashdot. For some time I also kept a photoblog. (In the past, I made many postings to usenet.) My mother tongue is Dutch& (http://www.iwriteiam.nl)

=====Blogjects e.d.=====
*Nano zetpil die data verzameld
*RFID inslikken, nanobots
*Blogjects: realtime: hartslag, bloeddruk, transpiratie, geur, temperatuur, altitude, speed, kijkrichting, relaxheid, sound volume, spraakherkenning, locatie, gebeld door
*CPU thermometers gebruiken als creative research methode om huiskamer temperatuur verspreid over de aarde vast te stellen.
*Tijdens het maken van een foto zoveel mogelijk extra gegevens opslaan over locatie, tijdstip, temperatuur op verschillende plekken op de foto (weet je misschien meteen hoeveel mensen er op staan), geluid op dat moment, beweegt het gefocusde onderwerp ja of nee. Etc.

=====Foto's op Flickr en andere webservices=====
*Met veel camera's op hetzelfde moment een foto maken. Hoeveel foto's heeft flickr van identieke momenten?
*Google maps / earth / windows live / postcodes / telefoonnummers
*Foto met lage resolutie maar heel grote kijkhoek. Wat zie je dan?
*Zoek foto's op datum en Interestingness: http://www.flickrleech.net/interestingness/2007/01/05/
*[[Flickr]] foto's uit het verleden
*Wereldkaart helemaal bestaand uit foto's gemaakt op dat punt. Manieren om de kaart van de aarde te laten genereren op basis van data (foto's, steden, lichtjes, temperatuur)
*Spraaksynthese: [[ALICE]] is betere versie van ELIZA
*Photosynth/Seadragon: http://www.ted.com/index.php/talks/view/id/129

=====Interface design=====
*Meaningless metaphor
*Metaphorless interface
*Analogieen / metaforen. Hoe bestaande modellen te gebruiken om iets anders (evt. Iets nieuws) te visiualiseren.
*Bij zoekmachines selectie verfijnen. Bij afbeeldingen met shift bepaalde afbeelingen excluden. Door lagen heenprikken

=====Information aesthetics=====
*Originele capchas: turfjes op http://www.visualcomplexity.com/vc/
*Vivisimo, wikipedia, open directory, word net, visualcomplexity.com
*Data visualisatie
*IO plakband
*Iets met postcodes en/of netnummers

=====Bio / brain / bewustzijn=====
*DNA een rekensom laten oplossen, iets over gaan opzoeken
*Wat als 1 van de processierupsjes doodgaat?
*Wat zou de volgende hersenschil moeten worden?
*Dia experiment (van Nibbet?). Acties voorspellen
*EEG met geluidskaart
*Bewustzijn als virus ipv software
*Neuron.exe onderzoek doen naar de haalbaarheid van mijn column. Komen evolutionary algoritms in voor en op bepaalde manier ook Social Enginering. Misschien wel op basis van het Blogjects project maar dan de data gebruiken voor de kunstmatige neuronen.
*2001 Space Odysee
*1938 HC Wells "World Brain"

=====Wiskunde / Natuurkunde / algoritmes=====
*Evolutionary LSystem Algoritms with Springs (of beter body dynamics) and Social Enginering 'for young disabled children ;-)'
*Physical twists to classic games. Like Gravity Tetris
*Self organizing systems
*Fibonassi Spiral
*Elektromagnetisch spectrum

=====Soorten programmeertalen e.d. hmm=====
*Formules opbouwen uit blokjes (visueel programmeren)
*Functioneel programmeren

=====Human-based evolutionary computation =====
*Evolutionaire algoritmes en [[Social Enginering]]. 10000 people drawing sheep facing ([[Aaron Koblin]]) left vind ik een heel mooi voorbeeld. Mensen gebruiken bij de criteria voor evol. alg. Ow wacht 's, dat is een heel ander project. Hoe heet dat project met die blokjes? Dat je moet zeggen of ie wit of zwart moet zijn? En dan misschien ook wel met grijstinten afhankelijk van hoeveel de mensen elkaar tegenspreken.
*User-centric Evolutionary Computation, Human-based evolutionary computation etc.
*Soort spel waarbij je 'pixels moet raden' in een leeg vlak. Opdracht bijv. Nederlandse vlag. Als je het goed hebt verdien je punten ofzo of mag je van categorie wisselen ofzo. Beloning iig.
*Levensvormpjes/creatures tonen en die door mensen een naam laten geven. 
*Spore game
*Stickers in de trein plakken 

=====Flauw / Fun=====
*VOC chip (ipv VOC schip). Een bootje met een chip die de hele tijd Toch? zegt.
*Vreemd: Nevenstaand flow afwerken
*Is this a rethorical question or is this a rethorical question?
*What is a question that mentions the word umbrella for no apparent reason?
*Rails, het meest achteruit gelezen tijdschrift. In twee opzichten. Achteruit rijdend in de trein, maar vooral dat het een tijdschrift is waarbij iedereen achterin begint en naar voren bladert. Misschien moeten ze eens proberen of het aanslaat de pagina's van achter naar voor te laten lopen. Zijn ze experimenteel genoeg voor.

=====Emotionele waarde=====
*Experiment waarbij ik alles wat ik in m'n huis heb staan te koop zet voor de emotionele waarde. Alles wat je hebt opnieuw inventariseren en op waarde inschatten.

===== Shephards tone =====
A Shepard tone, named after Roger Shepard, is a sound consisting of a superposition of sine waves separated by octaves. When played with the base pitch of the tone moving upwards or downwards, it is referred to as the Shepard scale. This creates the auditory illusion of a tone that continually ascends or descends in pitch, yet which ultimately seems to get no higher or lower.[1]

===== Diversen=====
*Boek: [[Bruce Sterling - Shaping things]]
*Tip van [[Koert]]: Boek: [[Elise van Hoven - Recollecting Physical Objects]] (over herinneringen die fysieke objecten oproepen)
*Eigenlijk is je HD een filter, een buffer waar alle ruwe data op staat en zelf kies je welke in aanmerking komen om te delen
*Firefox plugin waarmee je relevante stukken tekst kunt selecteren en daarmee voeg je [[metadata]] omdat je voor jezelf de kern uit een verhaal haalt.
*De [[Papierverscanneraar]] / scanner vs. schredder  (Je stopt iets in een apparaat dat lijkt op een papier versnipperaar maar in werkelijkheid wordt het gescand en direct online geplaatst klaar om te worden voorzien van beschrijving/metadata door de eigenaar maar ook misschien door anderen.
*[[Screenhunter]] moet screenshots annoteren met tekst die binnen de selectie zichtbaar is en met evt. andere metadata zoals webadres waarvan het screenshot gemaakt is, naam van het window waarvan een screenshot gemaakt is, datum/tijd. Dit zou allemaal in [[EXIF]] data kunnen.
*Koop m'n huis leeg punt nl en colums schrijven over wat je die week allemaal bent kwijt geraakt.
