---
title: ofxManyMouse
---
ofxManyMouse is an addon for [[openFrameworks]] I created in [[2008]].

(  blog:2008.05.01-23.28-01.png?240|) At May 1st 2008 I finished a first version of the ofxManyMouse addon. This addon is based on the ManyMouse library by Ryan C. Gordon.

With this openFrameworks addon you can easily read values from multiple mouse devices. 

You can find it here: http://github.com/companje/ofxManyMouse

I hope it will be of use for you. Good luck!

(tag>Tech OpenFrameworks C++ Programming)

~~DISCUSSION~~
