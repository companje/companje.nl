---
title: CodeBlocks
---

====="An exception has been raised! The application encountered an error at C:\Codeblocks\src\sdk