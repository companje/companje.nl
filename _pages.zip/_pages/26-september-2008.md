---
title: 26 september 2008
---
De balans opmaken wat betreft mijn afstuderen.
*wat heb ik tot nu toe allemaal bereikt?
**Ik heb veel artikelen gelezen en gehighlight over data. Met name over Personal Information Management en Archivering e.d. Niet zozeer over het fenomeen van het delen van al je data by default.
**Ik heb een stukje geschreven over het standaard delen van je data. Een leuk stuk maar niet wetenschappelijk nog.
**Ik heb in november/december 2007 zinloze experimenten gedaan die buiten m'n afstudeergebied vallen ([[Papierverscanneraar]] en [[Rickipedia]])
*waar sta ik nu?
**Op dezelfde plek als in april 2008. Geen enkele stap verder. Eerder verder teruggeworpen bij gebrek aan toewijding.
*hoe dichtbij voelt m'n onderwerp nog?
**Geen verandering. Nog steeds geen volle overtuiging dat ik iets met dit onderwerp kan.
*samen met Maarten nadenken over een mogelijke nieuwe start (evt. ander onderwerp)
**Een afstudeerproject in de trend van mijn AI Research Seminar concept over een slimme mobiele memory agent.
