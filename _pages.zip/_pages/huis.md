---
title: Huis
---
(::schutstraat89.jpg?550|)

* [[http://goo.gl/forms/JZfovSONWdCvEK7b2|kosten bijhouden]]
* http://www.alles-over-een-huis-kopen.com/support-files/checklist-onderzoek-huis-kopen.pdf
* http://www.emerald.nl/financien/home.php (tip van Sylvain)
* http://www.paulmakelaars.nl/ (tip v Magriet)
* https://www.youtube.com/watch?v=QsOgxRioYBY
