---
title: Creative Coding
---
* http://thi.ng/
* http://toxiclibs.org/
* [[http://mrl.nyu.edu/~perlin/|Ken Perlin]]
* [[http://postspectacular.com/|Karsten Schmidt]]
* [[http://blog.blprnt.com/|Jer Thorp]]
* [[http://www.lab101.be/|Kris Meeusen]]
* [[http://mikepelletier.nl/|Mike Pelletier]]
