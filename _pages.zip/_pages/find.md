---
title: Find
---

=====find jpg's case insensitive=====
  find . -iname "*.jpg"
