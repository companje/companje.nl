---
title: Beamermannetje
---
Deze foto maakte ik tijdens het opbouwen bij het Innovaction festival in Italië. René Magritte zou trots op me zijn geweest.
 
(blog:beamermannetje.jpg?550|Beamermannetje)

(tag>Art Fun Photos)

~~DISCUSSION~~
