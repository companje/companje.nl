---
title: HTML5
---
* https://simon.html5.org/dump/html5-canvas-cheat-sheet.html 
* http://www.html5rocks.com/en/mobile/touch/
* [[https://github.com/cwilso/PitchDetect/blob/master/js/pitchdetect.js|pitch detection of captured sound input]]
* see [[WebRTC]], [[WebGL]], [[js]]
