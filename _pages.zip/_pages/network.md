---
title: Network
---

==get ip + mac address of all connected network devices==
<code>arp -an</code>
