---
title: PAL Signal
---
(::timing_pal_framesignal_progressive.gif?direct&600|)
