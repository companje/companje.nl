---
title: Mediamatic geeft al haar boeken weg
---
We heffen onze bibliotheek op...
Zaterdag 28 juni, 16.00 tot 21.00 uur
Zondag 29 juni, 12.00 tot 17.00 uur

Mediamatic geeft al haar boeken weg. "We stoppen met onze bibliotheek in protest tegen het huidge kunstsubsidie-beleid van het kabinet."

Alle leden van Mediamatic.net (en andere boekenliefhebbers) kunnen hun favoriete boeken gratis komen ophalen. Je hoeft het boek alleen aan je profiel te koppelen. En beloven dat je het boek altijd uit zult lenen als een ander lid er om vraagt. Zie daar, de gedistribueerde bibliotheek!

Wie het eerst komt, het eerst maalt. We hebben duizenden boeken, tijdschriften en multimedia die een nieuwe eigenaar zoeken. En er is muziek en een boekenbar.

http://www.mediamatic.net/page/39326/nl

Locatie: Mediamatic kantoor, Post CS gebouw, Oosterdokskade 5, vijfde verdieping, Amsterdam.

(blog:mediamatic-bibliotheek-39265-500-188.jpg?550|)

(tag>Media Books Tech Art Electronics)

~~DISCUSSION~~
