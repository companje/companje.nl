---
title: Quota
---

==show quota for user (v) human readable (s)==
  quota -vs USERNAME
  
==show quota for group (g) human readable (s)==
  quota -gs GROUP
  
==edit quota for group (opens in vi)==
  edquota -g GROUP
