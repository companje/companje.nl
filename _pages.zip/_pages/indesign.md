---
title: Indesign
---
* booklet total page count needs to be dividable by 4
* more tips: http://indesignsecrets.com/print-blank-pages-messes-up-print-booklet.php
* je kunt een booklet goed naar een postscript file printen en die vervolgens in acrobat weer openen voor het printen van meerdere copies.
* bij het printen naar postscript kun je custom paper size kiezen die dan automatisch de maat van je boekje aanneemt.
