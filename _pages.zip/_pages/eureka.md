---
title: Eureka
---
*Eureka is een beta wetenschappelijk tijdschrift van de [[Universiteit Leiden]]

===== Article about Globe4D in Eureka =====
Eureka!, a Dutch scientific magazine did an article on [[Globe4D]] which is now available as [[http://www.physics.leidenuniv.nl/eureka/pdf-magazines/eureka20.pdf|PDF]]. Two pages about our four-dimensional globe with detailed information about how it all started and about our future plans.
