---
title: Naar Suriname!
---
(  blog:2008:03:thebacklot.jpg?200|The Back Lot, Paramaribo, Suriname)Zondag 30 maart 2008 vertrek ik voor 10 dagen naar [[:Suriname]] om daar samen met [[people:Danica Mast]] en de Cinekid crew Globe4D te demo'en en workshops te gaan geven tijdens het Internationaal Speelfilm Festival IFFR Flies Paramaribo 2008. 

<blockquote>In het Venezolaans Instituut voor Cultuur en Samenwerking (IVCC) gaat 4,5 en 6 april The Talent Factory en Cinekid van start. De filmvertoningen, workshops en activiteiten voor kinderen en jongeren komen dit festival samen in één weekend. De jeugd kan deelnemen aan leuke, leerzame workshops en activiteiten. Een film kijken tijdens het doorlopende filmprogramma of genieten van optredens. (www.thebacklot.sr)</blockquote>

(tag>Travel Globe4D)


~~DISCUSSION~~
