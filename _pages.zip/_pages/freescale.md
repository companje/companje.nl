---
title: Freescale Freedom
---

* http://nl.farnell.com/jsp/search/productdetail.jsp?ICID=I-HPBL-sep-LTOFF-0201&SKU=2254491
Bij het bestellen code ‘KL05Z20’ voor nog meer korting
