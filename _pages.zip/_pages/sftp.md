---
title: sftp
---

* [[https://wiki.filezilla-project.org/Command-line_arguments_(Client)]]

<code>
sftp root@192.168.5.1:22
</code>

error: /usr/libexec/sftp-server: not found
