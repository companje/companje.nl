---
title: Cura
---
See [[Ultimaker]]

=====settings=====
windows: `C:\Users\user\AppData\Local