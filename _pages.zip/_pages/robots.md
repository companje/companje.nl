---
title: Robots
---
* Fanuc Robotics
* Kuka
