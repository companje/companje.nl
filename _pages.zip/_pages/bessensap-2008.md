---
title: Bessensap 2008
---
Op [[26 mei 2008]] is [[Globe4D]] de hele dag te zien geweest in [[NEMO]] op het Bessensap 2008 evenement van NWO.

<blockquote>Het Bessensap evenement brengt journalisten, redacteuren, voorlichters en mediagenieke onderzoekers dichter bij elkaar. Het motto: wetenschap ontmoet pers, pers ontmoet wetenschap.</blockquote>
