---
title: AppCache
---
quote from http://devdocs.io/offline: "How does this work? Each page is cached as a key-value pair in [[https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API|IndexedDB]] (downloaded from a single file). The app also uses [[https://developer.mozilla.org/en-US/docs/Web/HTML/Using_the_application_cache|AppCache]] and [[https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API|localStorage]] to cache the assets and index files."
