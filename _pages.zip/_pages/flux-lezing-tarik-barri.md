---
title: Flux lezing Tarik Barri
---
//Beelden horen, geluiden zien: over de kracht van audiovisuele compositie//  

Flux-lezing door: Tarik Barri

"Staat hij daar nu zijn email te checken met media player aan of zijn we getuige van een geniale improvisatie?"
Met de komst van electronica en computers op het podium is in toenemende mate onduidelijk geworden hoe de muziek tijdens electronische muziek concerten nu eigenlijk tot stand komt. De complexiteit en de onzichtbaarheid van de techniek vormen vaak een muur tussen het publiek en de artiest waarbij het publiek niet meer in staat is te zien hoe (en óf) de muziek hiér en nú live tot stand komt.
Tarik Barri, vorig jaar afgestudeerd als EMMA in Composition In Context aan de KMT, stelde zichzelf ten doel deze muur af te breken door het publiek met behulp van live bewegend beeld op intuïtieve en toegankelijke wijze in de creatie van de muziek te betrekken. Hij programmeerde de 3D audiovisuele muzieksoftware "Versum" om het publiek tot een directe getuige van zijn compositionele structuren en muzikale beslissingen te maken; men ziet de composities zich letterlijk voor zijn ogen ontvouwen. Tijdens de lezing zal Tarik zijn werk demonstreren en uitleggen welke beslissingen en motivaties, op zowel inhoudelijk als technologisch niveau, hem hebben gebracht tot zijn huidige manier van werken.

Dinsdag 8 december 2009 om 17.00uur
Auditorium (HKU Hilversum)
  	
Extra informatie:  
	
http://www.tarikbarri.nl  


(tag>Art Music Tech Events)


~~DISCUSSION~~
