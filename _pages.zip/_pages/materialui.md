---
title: MaterialUI
---

* https://material.io/icons
* peter: De Material-ui alpha release is uit, grootste verbetering is waarschijnlijk dat de styling veel beter geregeld is, doordat ze nu gebruik maken van JSS. 
https://material-ui-1dab0.firebaseapp.com/
