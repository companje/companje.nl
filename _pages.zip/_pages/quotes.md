---
title: Quotes
---
* “Do not walk in the footsteps of the sages. Instead, seek what they sought.” 
