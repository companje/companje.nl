---
title: Dates
---


===== Special dates by year =====
[[dates:1979]] |  [[dates:1980]] |  [[dates:1981]] |  [[dates:1982]] |  [[dates:1983]] |  [[dates:1984]] |  [[dates:1985]] |  [[dates:1986]] |  [[dates:1987]] |  [[dates:1988]] |  [[dates:1989]] |  [[dates:1990]] |  [[dates:1991]] |  [[dates:1992]] |  [[dates:1993]] |  [[dates:1994]] |  [[dates:1995]] |  [[dates:1996]] |  [[dates:1997]] |  [[dates:1998]] |  [[dates:1999]] |  [[dates:2000]] |  [[dates:2001]] |  [[dates:2002]] |  [[dates:2003]] |  [[dates:2004]] |  [[dates:2005]] |  [[dates:2006]] |  [[dates:2007]] |  [[dates:2008]]
