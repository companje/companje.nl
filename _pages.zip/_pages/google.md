---
title: Google
---

== Google sites favicon ==
* https://sites.google.com/site/siteshelphowtos/google-sites-instructions/images/favicon
