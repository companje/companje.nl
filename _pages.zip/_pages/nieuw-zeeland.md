---
title: New Zealand
---
In [[2005]] I travelled for six months in New Zealand.
\
*My travel journey is available as [[http://companje.nl/boek.pdf|PDF]] (in Dutch).
*A lot of photo material is available at my [[http://picasaweb.google.com/rick.companje/NieuwZeeland|Picasa Web Album of my trip to New Zealand]]

<html><a href="http://picasaweb.google.nl/rick.companje/NieuwZeeland/photo#5165814200981003586"><img src="http://lh6.ggpht.com/rick.companje/R7CopWkkHUI/AAAAAAAAC0s/piAb0407Qsc/s400/IMG_1289.jpg" /></a></html>
