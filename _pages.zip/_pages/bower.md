---
title: Bower
---

==bowerrc==
* be careful for the ~/.bowerrc file
* http://stackoverflow.com/questions/14079833/how-to-change-bowers-default-components-folder
