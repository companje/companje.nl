---
title: Generieke kastjes
---
Ik heb vandaag twee elektronische schakelingen gebouwd en in behuizingen gestopt met een net label erop. Een kant en klare Voltage Regulator die zorgt voor een stabiele 5V output en een Universal Solid State Relais voor het schakelen van 240V apparaten met bijv. een batterij of een microcontroller. Handige dingetjes die me nog regelmatig van pas zullen gaan komen.

=== Voltage Regulator en Universal Solid State Relais ===
(blog:voltage-regulator-500.jpg?270|Voltage Regulator) (blog:universal-solid-state-relais-500.jpg?270|Universal Solid State Relais)

(tag>Electronics)

~~DISCUSSION~~
