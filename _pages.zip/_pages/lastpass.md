---
title: Lastpass
---
* alternatives: Dashlane, 1Password, KeePass en Password Safe.
