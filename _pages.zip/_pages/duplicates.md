---
title: Duplicate files
---

===== install fdupes on mac =====
  brew install fdupes
  
===== find duplicates =====
  fdupes .
  
===== find and delete duplicates (removing the first one)=====
  fdupes -dN .

===== dupeGuru Picture Edition =====
This great tool finds duplicate images based on content.
* http://www.macupdate.com/app/mac/22724/dupeguru-picture-edition
