---
title: Apps
---

==Apps uitrollen over meerdere devices==
Zie: https://www.kennisnet.nl/artikel/in-een-klap-apps-installeren-op-alle-tablets-in-de-school/
