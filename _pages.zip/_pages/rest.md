---
title: REST
---

===== Generating REST API documentation =====
There are some tools to generate Rest api documentation. Usually this works by defining the api in a yaml like language and a html page can be generated from this.
  * Swagger. Result demo. Editor UI creator.
  * RAML. spec tutorial. on documenting.
  * Apiary. API blueprint tutorial. Editor (Editor also supports Swagger's language).
  * JSONDoc. Result Demo.
  * API Blueprint. Just a language? Used in combination with for example Apiary.
  * APIDOC. Demo. (creates a docs from API annotations in source code) Overviews / reviews
  * https://opencredo.com/rest-api-tooling-review/
