---
title: rEFInd boot manager
---

==skinning==
* http://www.rodsbooks.com/refind/themes.html
* http://askubuntu.com/questions/565439/installing-a-theme-for-refind-and-finding-refind-file-mac
