---
title: New York 2006
---
(youtube>large:uD15g9yj9WU)
(tag>Travel)
