---
title: protobuf
---
* https://github.com/google/protobuf
* https://developers.google.com/protocol-buffers/
