---
title: Disk Usage
---

===== size of current folder =====
```
du -sh folder
```
