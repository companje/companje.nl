---
title: het koesteren en delen van herinneringen in een digitaal tijdperk
---

Een essay door Rick Companje - 18 augustus 2009  

Heel vroeger werden herinneringen, verhalen en kennis voornamelijk in het hoofd bewaard en mondeling doorgegeven. De komst van eerst het schrift, toen de boekdrukkunst en tegenwoordig de digitale media hebben ervoor gezorgd dat deze herinneringen nu veel makkelijker, sneller en nauwkeuriger kunnen worden vastgelegd en verspreid. Tegenwoordig is het praktisch mogelijk alles wat je beleefd, wat je ziet en waar je over praat te delen met anderen via het Internet. Veel mensen plaatsen regelmatig een nieuw stuk op hun weblog of laten via een twitterberichtje weten waar ze mee bezig zijn. Daarnaast zijn er ook al mensen die letterlijk iedere letter die ze op hun toetsenbord aanslaan automatisch delen met de wereld. Er zijn mensen met een camera om hun nek die automatisch foto's maakt. Anderen dragen een apparaatje bij zich die het aantal voetstappen telt of je afgelegde route voor je vastlegt. Het willen onthouden van ieder detail van je leven en het willen vastleggen van iedere prikkel die er bij je binnenkomt heet lifelogging of lifecaching en wordt wereldwijd al door tienduizenden mensen gedaan. In dit essay werp ik een blik op het willen koesteren en delen van herinneringen in ons digitale tijdperk.

(:blog:companje-2009-essay-herinneringen-digitaal-tijdperk.pdf|Lees verder... (PDF))

(tag>Stories Ideas Study)

~~DISCUSSION~~
