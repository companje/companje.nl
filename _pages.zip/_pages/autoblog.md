---
title: AutoBlog
---
Ik ben bezig met een experiment. Ik noem het AutoBloggen. Het gaat uit van mijn idee Data Sharing by Default. Alles wat ik scan of waar ik een screenshot van maakt wordt nu in principe standaard geupload naar mijn [[AutoBlog:]]. Ik wil met zo weinig moeite zo veel mogelijk 'relevante' data delen. 

 
De volgende stap is dat ik mijn clipboard op dezelfde manier wil gaan delen. Omdat mijn clipboard een hoop over mij zegt en laat zien waar ik mee bezig ben. 't Zegt ook vast een hoop waar ik niet op zit te wachten, en de gemiddelde website bezoeker ook niet, maar ik ben benieuwd naar de resultaten.

Bekijk wat er tot nu toe op m'n [[AutoBlog:]] staat.

(tag>Ideas Blog)

~~DISCUSSION~~
