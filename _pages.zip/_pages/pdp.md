---
title: PDP8 / PDP11 computers
---

===== Dutch PDP8 replica =====
* http://obsolescenceguaranteed.blogspot.ch/2015/01/new-project-pdp-8i-replica.html (Oscar)

=====3D CAD files of PDP8 and PDP11 knobs=====
* http://so-much-stuff.com/pdp8/cad/3d.php
