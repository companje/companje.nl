---
title: Atom Editor
---

==Select Next: Cmd+D==
```
Cmd+D
```

==add project==
```
atom -a .
```

==install packages via CLI==
  apm install glsl-preview
  
==shortcuts==
```
Cmd P
Cmd Shift P
Cmd ,
```

==packages==
  * https://atom.io/packages/linter
  * https://atom.io/packages/linter-eslint
  * https://atom.io/packages/linter-jsonlint

Ook fijn: 
  * https://atom.io/packages/split-diff
  * https://atom.io/packages/auto-detect-indentation
  * https://atom.io/packages/file-icons
  * https://atom.io/packages/highlight-selected
  * https://atom.io/packages/linter-csslint
