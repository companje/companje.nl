---
title: FabLab Amersfoort van start op 12 september 2010
---
(  http://www.opentoko.org/wp-content/uploads/2010/09/fablab-opening-150x150.png)Mede door het grote succes van de OpenToko’s van de afgelopen tweeënhalf jaar opent FabLab Amersfoort vanaf zondag 12 september officieel haar deuren voor het publiek. Tijdens Open Monumentendag kan iedereen kennismaken met de mogelijkheden van Amersfoorts eerste open werkplaats met machines voor digitale fabricage.

Het FabLab faciliteert uitvindingen en innovatie door computergestuurde gereedschappen binnen het bereik van individuen te brengen. Het biedt een plek voor ontwerpers, kunstenaars, uitvinders en anderen om kennis te maken met Personal Fabrication en rapid prototyping. Digitale ontwerpen kunnen m.b.v. een lasersnijder, een digitale freesmachine en een snijplotter snel worden uitgewerkt in hout, plexiglas, rubber, zelfklevend vinyl, papier, karton, textiel etc.

Ook fungeert het FabLab als ontmoetingsplek voor makers uit de creatieve sector. FabLab Amersfoort is een initiatief van de Spullenmannen en maakt deel uit van het wereldwijde netwerk van FabLabs dat werd opgezet door het MIT.

FabLab Amersfoort is open op zondag 12 september van 12:00 tot 17:00 met om 15:00 de officiële opening. Daarna is het FabLab iedere dinsdag open van 10:00 tot 17:00.

==Waar:==
*Kleine Koppel 40, Amersfoort
*http://www.fablabamersfoort.nl/route

==Wanneer:==
*Zondag 12 sept. 2010 van 12:00 tot 17:00.
*Daarna elke dinsdag van 10:00 tot 17:00.

Kijk voor meer informatie op www.fablabamersfoort.nl.

(http://www.opentoko.org/wp-content/uploads/2010/09/fablab-opening-1.png)

(http://www.opentoko.org/wp-content/uploads/2010/09/fablab-opening-2.png)

(tag> FabLab, digital fabrication, machines, creativity, events, projects, art, tech, design)


~~DISCUSSION~~
