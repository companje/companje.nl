---
title: Character Encoding
---

* http://www.motobit.com/util/charset-codepage-conversion.asp
* http://www.joelonsoftware.com/articles/Unicode.html

===== unicode character lookup =====
* http://unicodelookup.com/

=====to enter unicode character on osx=====
see [[osx]]
