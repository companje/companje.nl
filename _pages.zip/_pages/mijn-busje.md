---
title: Mijn busje!
---
Ik heb een camperbusje gekocht! Een witte Renault Estafette uit 1976!
(blog:renault-estafette.jpg?500|Renault Estafette Oldtimer camper)

(tag>Travel)

~~DISCUSSION~~
