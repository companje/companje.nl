---
title: 3D printen met de Ultimaker
---
Een paar maanden geleden ben ik begonnen met het bouwen van een [[http://ultimaker.com|Ultimaker]], een zelfbouw 3D printer ontworpen door Martijn, Erik en Siert bij het FabLab van Utrecht. De machine print laagje voor laagje een 3D object van plastic. Inmiddels doet mijn exemplaar het maar nu is het een kwestie van 'm goed leren kennen zodat alles goed op elkaar is afgestemd: warmte, snelheid etc.
Benieuwd naar de printer, kom naar [[http://fablabamersfoort.nl|FabLab Amersfoort]] want daar kun je 'm iedere dinsdag van 10:00 tot 17:00 bekijken én gebruiken.
\
(:blog:fablab-amersfoort-ultimaker.jpg?550|)

(tag>Tech 3D FabLab Ideas Projects)


~~DISCUSSION~~
