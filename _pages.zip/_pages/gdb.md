---
title: =====GDB (GNU Debugger) =====
---

<code>
gdb datamining
(gdb) run
(gdb) bt
</code>

==Debugger settings in CodeBlocks==
Je kunt catch debugger exceptions flag uitzetten want bij het debuggen zijn exceptions die netjes afgevangen worden meestal helemaal niet erg.
