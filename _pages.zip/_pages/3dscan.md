---
title: 3D Scanning
---
* http://structure.io & Itseez3d (tip van Bart van V)
* ...
