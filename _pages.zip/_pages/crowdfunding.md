---
title: Crowdfunding
---

* http://kickstarter.com
* create hypes with: http://thunderclap.it
