---
title: Foto van Einstein
---
Ik ben verhuisd vorige week naar Katwijk. Deze foto van mijn Einstein Action Figure maakte ik 2 woningen geleden toen ik nog in Rijswijk woonde.

(blog:einstein.jpg?550|)

(tag>Photos)

~~DISCUSSION~~
