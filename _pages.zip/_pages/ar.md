---
title: Augmented Reality
---

* Magic Leap: [[http://en.wikipedia.org/wiki/Magic_Leap|wikipedia]], [[http://gizmodo.com/how-magic-leap-is-secretly-creating-a-new-alternate-rea-1660441103|gizmodo]]
