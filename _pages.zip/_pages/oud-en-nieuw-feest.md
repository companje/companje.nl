---
title: Oud en nieuw feest
---
<blockquote>
Beste vrienden en bekenden,
\
Volgende week donderdag avond 24 september organiseer ik met een aantal anderen een spetterend oud en nieuw feest in stadscafé de Observant, ter gelegenheid van Earth Overshoot Day de dag erop. Ik nodig jullie van harte uit om er bij te zijn en onder het genot van een oliebol dit bijzondere moment mee te maken. Zie de bijlage voor meer informatie.
\
veel groeten,
Harmen Zijp
</blockquote>

(:blog:overshootparty2009-nl.pdf|Uitnodiging voor oud en nieuw feest)

(tag>Events Art)


~~DISCUSSION~~
