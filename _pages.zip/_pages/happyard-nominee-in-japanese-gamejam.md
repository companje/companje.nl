---
title: Happyard nominee in Japanese Gamejam
---
A couple of weeks ago a team of five: Joost Broersen, Matthijs Rouw, Florus van Beek, Ralph Kok and myself developed a gaming concept we called [[Projects:Happyard]] for the Japanese mobile market. We did this in the context of the GameJam competition which was organized with the intent of promoting dutch design in Japan through mobile gaming.
 
<blockquote>[[http://www.happyard.jp|(  blog:2008:03:logo-gamejam.png?250|Happyard)]]
The Japan Times describes Happyard very much to the point as a game that “(…) integrates real world parameters with a virtual garden environment and sets the player about hunting animals for their collection.” This concepts enthused the Japanese jury so much that they decided on us as the fourth competitor where a selection of just three was allowed (!) So on to the demo creation phase and perhaps this fall we’ll be representing dutch design in Tokyo!</blockquote>

http://search.japantimes.co.jp/cgi-bin/nc20080319a1.html 
http://www.nieuwsbank.nl/inp/2008/03/18/G016.htm 
http://www.florusvanbeek.nl/blog 
http://blog.thingsdesigner.com 
http://www.rockabit.com 
http://www.happyard.jp 
http://www.gamejam.nl 

(tag>Games Tech Mobile Interaction)

~~DISCUSSION~~
