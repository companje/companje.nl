---
title: Azure
---

"...Azure, Microsoft's cloud computing platform, that will allow you to send your data from one platform to the other securely."
