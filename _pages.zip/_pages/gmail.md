---
title: gmail shortcut keys
---
? shortcut keys help

gk voor goto tasks
U mark as unread
I (hoofdletter i) mark as read
~ en ` vorige en volgende inbox section
TAB in tekstveld om focus te verliezen zodat de shortcuts werken
, ga naar toolbar en dan met TAB wisselen tussen buttons
