---
title: Polymer
---
* http://www.binpress.com/blog/2014/06/26/polymer-vs-angular/
* https://www.youtube.com/watch?v=irGDN5Ysi_A&t=21m45s
* [[https://www.youtube.com/watch?v=8OJ7ih8EE7s|Google IO Polymer and the Web]]
* https://www.chromestatus.com/features
* http://customelements.io/
* http://googlewebcomponents.github.io
