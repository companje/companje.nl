---
title: How MS will know ALL about you
---
ID: Coursey (2003)
PDF: (afstuderen:coursey-2003-how-ms-will-know-all-about-you.pdf|)

===== Summary =====
*You're not that interesting (and neither am I).
*who'd actually want to see it?
*when you take over someone else's project and need to find out everything you can about what your predecessor was doing
*wants to prove he didn't violate the law by propping up worthless stocks.
*someday in the future, to find out what our grandparents' lives were like.
*Really Interesting People--a Nobel prize winner, say, or Madonna.  (BAH)

*Ik vind beroemde mensen juist helemaal niet zo interesant. Misschien hebben zich tijdens hun leven wel weten te onderscheiden van de massa door een bepaald talent, maar betekent dat ook dat ze op de lange het beste een beeld geven van de maatschappij op dat moment? nee. Het is juist interessant voor historici om te weten hoe de mainstream leefde. Er leefden niet alleen farao's in Egype en ook niet alleen wetenschappers en filosofen in 17de eeuw...
*Maar blijkbaar zijn beroemde mensen wel het meest succesvol in interesant blijven.

*Microsoft is planning to incorporate just such a database/file system into a future operating system,
*I'd be interested sometimes in looking back at what I was doing years ago. I'd also be interested in my parents' and grandparents' lives, if more of their data was available to me.
*privacy issues
*MyLifeBits is really more of a brain teaser--in a "Gee, that would be cool," or "Gee, what would they do with all that information?" or even, "Gee, why would anyone want to do that?" kind of way--than a real prototype application.
*The projects is, however, an answer to a question that's been bugging me ever since e-mail became popular
*how will we study and understand historically significant people in the future?
*If MyLifeBits turns into something real, we could once again leave a complete record (perhaps too complete) for those who come after us--and they could have the tools to wade through it.
