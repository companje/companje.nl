---
title: HappyChaos 2008
---
Op [[24 mei 2008]] staat [[Globe4D]] op HappyChaos, een inspirerende avond vol discussie, kunst en muziek over de technologische cultuur waarin wij leven: Genesis 2.0

<blockquote>De producten en systemen die een handvol mensen in laboratoria ontwikkelt, regeren over ons leven. happyChaos gaat in Genesis 2.0 op zoek naar de toekomstversnellers bij uitstek; technologische ontwikkelingen die de komende jaren maatschappelijke dynamiek gaan veroorzaken, controverse zullen oproepen en een grote impact op ons dagelijks leven gaan hebben. Is deze technologie van de toekomst onze nieuwe verlosser? Is het geloof in de technologie onze nieuwe religie? En gaan we met zijn allen richting het beloofde land waar alles mogelijk is? Tijdens Genesis 2.0. verkennen wij samen met ‘gelovigen’ en ‘ongelovigen’ het technologisch paradijs.

Wetenschappers, ondernemers, journalisten, filosofen en kunstenaars zullen op 24 mei in Pakhuis de Zwijger hun toekomstvisies aan ons voorschotelen. Zij delen hun inspirerende, verontrustende of juist geruststellende ideeën met ons en gaan met het publiek in debat over de gevolgen van de toekomstversnellers.</blockquote> 
