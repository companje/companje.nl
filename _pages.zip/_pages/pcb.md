---
title: PCB
---
* http://www.seeedstudio.com/
* http://www.eurocircuits.nl/
* http://www.eleshop.nl/
* https://oshpark.com/
* http://dirtypcbs.com
* http://www.voltera.io/

==software==
* http://www.freepcb.com/
* http://123d.circuits.io/


=='Scratching' PCB's on an Ultimaker==
* Het is inderdaad een erg leuke truuk om op die manier zelf een PCB'tje te maken zonder dat je hoeft te frezen. Eerst maak je een printplaatje helemaal zwart met een permanente viltstift. Dan bevestig je een scherpe naald aan de kop van je Ultimaker om op sommige plekken de zwarte inkt weg te laten krassen (met FlatCAM kun je gcode voor de Ultimaker maken van een Gerber bestand). Vervolgens leg je je print in ets-vloeistof en wordt alleen het koper opgelost op de plek waar de inkt is weggekrast is.

Een ander leuke bijkomstigheid is dat door het gebruiken van SMD componenten je geen gaatjes hoeft te boren.

Hier wordt het allemaal uitgelegd: http://randomdata.nl/wiki/index.php/PCB_fabrication_from_scratch
