---
title: A Digital Dark Ages
---

Lang artikel, niet helemaal gelezen.

ID: Kuny (1998)
PDF: (afstuderen:Kuny (1998) - A Digital Dark Ages.pdf|)

===== Summary =====
*Monks and monasteries played a vital role in the Middle Ages in preserving and distributing books. It was their work which provided much of our  present knowledge of the ancient past and of the rich heritage of Greek, Roman and Arabic traditions.
*living in what Umberto Eco has called an epoch of forgetting.
*preserve the historic record in an electronic era where change and speed is valued more highly that conservation and longevity.
*much of what is coded and written electronically, will be lost forever.
*Enormous amounts of digital information are already lost forever .... think punch cards and 12 floppy disks)
*Information technologies are essentially obsolete every 18 months.
*new product lines, often without backwards compatibility
*or companies themselves disappear.
*merely copying bits is not sufficient for preservation purposes.
*...
*libraries and archives are too often considered to be competitors to publishers
*digital culture, ... If history and cultural heritage are to be important, then it will likely fall to librarians and archivists, the monastic orders of the future, to ensure that something of the heady days of our digital revolution remains for future generations.

Quote: "Those who cannot remember the past are condemned to repeat it." (George Santayana, The Life of Reasson, 1906)
