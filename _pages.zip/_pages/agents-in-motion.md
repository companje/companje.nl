---
title: ===== Agents in Motion =====
---
( projects:agents-in-motion.jpg||Agents in Motion)== An Excursion in Video Art Using Flies, Max/MSP and Jitter ==
This project aims to use virtual agents to analyze video input and locate the highest intensity of perceived movement within it. The agents, symbolized here as fruit flies perform video analysis based on natural rules of interaction, which creates an organic swarming effect. To give an impression of the movement of the flies over time, a 3D visualization is provided.
===
*(projects:kok-kranendonk-companje-2007-agents-in-motion.pdf|Download article as PDF)

(tag>Art Projects Study)
