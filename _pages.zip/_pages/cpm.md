---
title: CP/M
---

==introduction to cpm==
http://obsolescence.wix.com/obsolescence#!introduction-to-cpm/c12tf

==copy a file==
```
PIP FILE.DST=FILE.SRC
```

==erase a file==
```
ERA FILE.EXT
```

==CP/M on the Altair8800==
* [[https://www.youtube.com/watch?v=BQq6ad9F3Xk|CP/M on the Altair8800 movie]]

==very good explanation about the Assembler(s)==
* http://www.shaels.net/index.php/cpm80-22-documents/using-cpm/9-asm-utility

==hello world example using ASM.COM==
* https://wiki.polaire.nl/doku.php?id=cp_m_assembler_example

==WordMaster keyboard shortcuts==
* [[wm]]
