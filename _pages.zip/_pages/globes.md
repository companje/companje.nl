---
title: (Virtual) Globes
---
see [[maps]]
* http://www.globalgeology.com/
* https://worldview.gallery/
* https://en.wikipedia.org/wiki/WorldWide_Telescope
* https://en.wikipedia.org/wiki/Virtual_globe
* https://code.google.com/archive/p/jdem846/
* http://planetmaker.wthr.us/
* http://mousebird.github.io/WhirlyGlobe/
* http://mapmaker.education.nationalgeographic.com/

* http://dagik.org/screen_shots/movies/
* http://www.dagik.net/app/download/6998569390/dagikearth_eng_2014.pdf
* [[http://www.supinemusic.net/Files%20for%20Cloud%20projects/Cinema%204D/plugins/Planet%20X%20Generator%20R12/presets/|Planet Textures]]
* http://eclecti.cc/computergraphics/snow-globe-part-one-cheap-diy-spherical-projection
* http://vterrain.org/Textures/spherical.html
* https://code.google.com/p/jdem846/
* http://celestia.h-schmidt.net/earth-vt/
* http://data-arts.appspot.com/globe/
* http://blog.apoapsys.com/2013/05/23/bored-then-create-a-planet/
* http://www.globe4d.com
* http://cesium.agi.com/
* http://www.virtualglobebook.com
* http://www.evl.uic.edu/pape/data/Earth/
* http://astro.uchicago.edu/cosmus/technotes.html
* https://www.youtube.com/watch?v=xS8vDVCHF9c
* http://www.pufferfishdisplays.co.uk/products/puffersphere-xl/
* https://www.flickr.com/photos/pierdr/17178440242/in/album-72157649696023373/

* texture and lighting sphere with WebGL: [[http://blog.thematicmapping.org/2013/09/creating-webgl-earth-with-threejs.html|tutorial]], [[http://thematicmapping.org/playground/webgl/earth/|demo ]]

* [[projection mapping]]

* Panoramatic 360 globe
* [[http://alteredqualia.com/xg/examples/earth_bathymetry.html|tip van Pieter]]
