---
title: ===== PPM (Portable PixMap), PGM (Portable GreyMap), PBM (Portable BitMap) ======
---
* see also [[rgb]]

<code>
(echo "P5 512 4096 255"; cat filename) > foo.pgm
</code>

<code>
(echo "P4 512 4096 255"; cat filename) > foo.pbm
</code>

* https://vimeo.com/110257380
* http://paulbourke.net/dataformats/ppm/
