---
title: Basic
---
* Basic interpreter for Arduino: https://github.com/robinhedwards/ArduinoBASIC
* Altair Basic source explained: http://altairbasic.org/
