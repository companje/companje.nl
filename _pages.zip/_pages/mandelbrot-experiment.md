---
title: Mandelbrotset
---
Ik heb me voorgenomen weer eens wat vaker te experimenteren met beroemde wiskundige functies en het afbeelden daarvan. Een functie die ik al heel lang erg mooi vind maar zelf nog nooit had uitgeprobeerd is de [[http://nl.wikipedia.org/wiki/Mandelbrotverzameling|Mandelbrotset]].  Al begrijp ik nog niet goed het complexe getallen werken, het programmeren van een interactieve versie van de Mandelbrotset lukt me wel. Klik op de onderstaande afbeeldingen om de Processing sketch te openen. Met de muis kun je fractal slepen en met shift en de muis kun je in- en uit- zoomen tot in beperkte mate. De sourcecode staat [[http://companje.nl/processing/MyMandelbrot/MyMandelbrot.pde|hier]].
\
[[http://companje.nl/processing/MyMandelbrot/|(:blog:mandelbrot2.png?250)]] [[http://companje.nl/processing/MyMandelbrot/|(:blog:mandelbrot.png?250)]]

(tag>Tech Math)


~~DISCUSSION~~
