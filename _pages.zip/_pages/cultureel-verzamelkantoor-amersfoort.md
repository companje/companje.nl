---
title: Cultureel Verzamelkantoor Amersfoort
---
Nico en ik zijn met Globe4D sinds begin februari gevestigd in de oude luciferfabriek van Amersfoort aan de Kleine Koppel 40. We huren een plekje op de eerste verdieping in het gebouwencomplex dat tegenwoordig dienst doet als cultuur verzamelkantoor en creatieve broedplaats.

We zijn nu voorzien van alles wat we nodig hebben om Globe4D nog verder te kunnen doorontwikkelen en aan te kunnen bieden:  kantoorruimte, een afgesloten  vergaderruimte, een demonstratie ruimte voor de globe en de nodige opslag. Daarnaast huren we een deel van de werkplaats van [[http://www.spullenmannen.nl|De Spullenmannen]] waar we onze Globe4D modellen nog verder kunnen perfectionaliseren en waar we bezig zijn met de ontwikkeling van een aantal gloednieuwe nieuwe installaties!

Hier enkele sfeerbeelden van onze ruimte.

(:blog:cultureel-verzamelkantoor-amersfoort.jpg)



(tag>)


~~DISCUSSION~~
