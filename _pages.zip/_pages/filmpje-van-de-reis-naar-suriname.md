---
title: Filmpje van de reis naar Suriname
---
Hier een filmpje van de reis met [[:Globe4D]] en [[:Cinekid]] naar [[:Suriname 2008|Suriname]].

(youtube>large:AQEHmQxrscA)

(tag>Travel Globe4D Events)

~~DISCUSSION~~
