---
title: Next Nature
---
You really should check out the Next Nature blog. It's all about Nature vs. Culture... Nature 2.0. [[http://www.nextnature.net/]]

<blockquote>Next nature deals with the idea that our technological world has become so intricate and uncontrollable that it becomes a nature of its own. Products of culture, which we used to be in control of, tend to outgrow us and become autonomous. This means we have to re-investigate our notion of nature</blockquote>

(blog:next-nature.jpg?550|)

(tag>)

~~DISCUSSION~~
