---
title: Elektronica
---

see [[electronics]]

==condensatoren==
* http://www.justradios.com/uFnFpF.html

*http://reichelt.de
* **R = U / I**
  * ofwel: Weerstand = Spanning / Stroom 
  * ofwel: Ohm = Volt / Ampère (Wet van Ohm)

* **P = I * U**
  * ofwel Vermogen = Stroom * Spanning 
  * ofwel Watt = Ampère * Volt

* Watt = Ampère<sup>2</sup> * Ohm
* Watt = Volt<sup>2</sup> / Ohm
* Ampère = Watt / Volt
* Volt = Watt / Ampère

Meer op: http://www.popschoolmaastricht.nl/college_spanning_stroom.php
