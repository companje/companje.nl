---
title: Cool Cucumbers; Privacy, Security & RFID
---
(blog:2008:03:cool-cucumbers:komkommer03.jpg?100 |)MediaTechnology and ArtScience present an informal evening with inspiring speakers, discussions and drinks.

This is the first of a series of evenings that aim to inspire, refresh and surprise you with topics that explore the boundaries of art and technology. This first evening is focused around ambient technology; computers that are all around us, yet invisible. What ethical questions do these developments raise? How does art use or abuse these emerging technologies? And what do cucumbers have to do with it?

* **Rob van Kranenburg** thinks about the cultural and social consequences of developments in ubiquitous computing
* **Pawel Pokutycki** works at the AR+RFID lab at the KABK and will talk about how art has dealt with the implications of RFID.
* **+ more...**

Thursday 27th of March 2008
Bar open at 19.00, speakers start at 20.00
Entrance is free

De Illusie
Casuariestraat 16
2511 VB The Hague

Everyone is welcome so brings your friends!
A website with even more information will be coming soon...

(tag>MediaTech Art Science Tech)

~~DISCUSSION~~
