---
title: Backup
---

* see [[osx]], [[duplicates]]
* [[http://bombich.com/|Carbon Copy Cloner]] for osx
