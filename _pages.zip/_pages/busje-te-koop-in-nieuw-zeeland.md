---
title: Busje te koop in Nieuw Zeeland
---
Hallo allemaal,
\
Ik zit momenteel voor 6 weken in Nieuw Zeeland en heb bij aankomst een mooi busje gekocht. **Eind januari 2011** vertrek ik weer. Is er iemand geinteresseerd om mijn busje over te nemen tegen die tijd?
Het is een witte Toyota Townace uit 1993, automaat, diesel en 4WD (al heb ik die zelf niet gebruikt). Je krijgt er een hoop kampeerspullen bij zoals kookstel, bodyboard, vodafone, sim-kaart en meer. De bus is uitgerust met een fijne matras. Ook zit er een autoradio met cd-speler in. De km-teller staat op 264009. De bus ziet er van buiten erg goed uit. De vorige eigenaar (inwoner van NZ) heeft 'm onlangs nog laten spuiten. Ook zitten er nergens deuken in tegenstelling tot veel andere busjes die je hier ziet. Technisch is de bus ook goed in orde. Ik heb 'm laten nakijken door een garage en die heeft het nodige gecontroleerd en vernieuwd (gloeibougies gecheckt, kleppen bijgesteld, nieuwe brandstoffilter, luchtfilter schoongemaakt).
\
Mijn vraagprijs is 3000 NZD (1750 euro).
\
Als je geinteresseerd bent kun je me bellen op +64 21 139 7460 of hieronder een berichtje achterlaten.
\
Groetjes Rick

(http://farm6.static.flickr.com/5084/5284039936_71556cb569.jpg)

(tag>Travel)


~~DISCUSSION~~
