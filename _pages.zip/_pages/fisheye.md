---
title: Fish-eye Projection
---
* http://www.domebase.org/building-the-mini-dome/fisheye-projection-lens
* http://paulbourke.net/dome/
* http://paulbourke.net/dome/mirrordome/
* http://paulbourke.net/dome/faq.html
