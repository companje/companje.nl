---
title: Kermit
---
* http://www.columbia.edu/kermit/kermit.html
* [[http://macappstore.org/c-kermit/|Kermit for Mac OSX]]
