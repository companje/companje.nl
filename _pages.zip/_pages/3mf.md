---
title: 3MF - 3d manufacturing format
---
* http://3mf.io/wp-content/uploads/2015/04/3MFcoreSpec_1.0.1.pdf
