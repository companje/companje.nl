---
title: iPhoto
---

=====Splitting iPhoto Libraries=====
Tip: In case of a very large iPhoto Library it might be handy to export all photos of one year and put them in a separate iPhoto Library. The export feature can use event names as folder names which is really helpful during the import for creating events.
