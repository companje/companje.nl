---
title: Museum for Natural History in Maastricht
---
Since February, one of our [[Globe4D]] models is on permanent display in Maastricht in The Netherlands. First as part of the China Dino exhibition in Centre Céramique. After April as part of the collection of the Museum for Natural History in Maastricht.

(:natuurhistorisch-museum-maastricht-globe4d.png|)

<html><object style="height: 335px; width: 550px"><param name="movie" value="http://www.youtube.com/v/_HBAwzF9uMk?version=3&feature=player_profilepage"><param name="allowFullScreen" value="true"><param name="allowScriptAccess" value="always"><embed src="http://www.youtube.com/v/_HBAwzF9uMk?version=3&feature=player_profilepage" type="application/x-shockwave-flash" allowfullscreen="true" allowScriptAccess="always" width="550" height="335"></object></html>

(tag>Globe4D Museums)

~~DISCUSSION~~
