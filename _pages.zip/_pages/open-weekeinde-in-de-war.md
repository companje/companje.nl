---
title: Open weekeinde in De War
---
Op 22 en 23 januari zijn er open dagen in 'de War', de plek in Amersfoort waar het al jaren bruist van de underground cultuur en wetenschap.
Kunstenaarscollectief de Spullenmannen werkt al ruim acht jaar in de oude kleurstoffabriek Warner en Jenkinson aan de Eem. Vanuit deze plek zijn de laatste jaren heel wat initiatieven gestart die de plek tot meer maken dan alleen een kunstenaarsatelier. Tijd om deze ontmoetingsplek voor de Amersfoortse underground scene op de kaart te zetten.
\
* **FABLAB AMERSFOORT** is een open werkplaats waar iedereen gebruik kan maken van de nieuwste digitale productietechnieken.
* In het **TRANSITIELA**B wordt gewerkt aan kleinschalige lowbudget oplossingen voor duurzame energie en voedselvoorziening.
* Het **STUDIUM GENERALE AMERSFOORT** presenteert maandelijks een lezing door een interessante wetenschapper.
* Tijdens de **OPENTOKO** workshops draait het om open kennisuitwisseling tussen kunstenaars, techneuten, programmeurs en wetenschappers.
* **FESTIVAL FRANJE** is sinds vier jaar hèt podium voor ondernemende podiumkunstenaars.

Regelmatig worden kleine voorstellingen en try-outs gespeeld op **PODIUM DE WAR**.
En natuurlijk zijn er de projecten van de **SPULLENMANNEN** zelf, zoals afgelopen jaar 'de Pers', 'de Waan' en het 'Knopjesmuseum'.

Kijk voor meer info op [[http://dewar.nl]]

(tag>Events)


~~DISCUSSION~~
