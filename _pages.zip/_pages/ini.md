---
title: INI files
---
* [[https://github.com/jasongao/DaVinci1.0/blob/master/DaVinci1.0-Cura-config.ini|Cura ini file using tabs for multi-line values]]
