---
title: Parallels
---

==Parallels tools==
* http://download.parallels.com/desktop/v5/docs/en/Parallels_Desktop_Users_Guide/22507.htm

==network bridge==
bridge the nework through Virtual Machine->Configure->Network to get in the same subnet as the Host operating system.
