---
title: HTML
---

==slider==
<code html>
<label for="maxScale">Maximum scale:</label>
<input id="maxScale" type="range" min="0.5" max="1.0" step="0.1"/>
</code>
