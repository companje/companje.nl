---
title: Installing Code Blocks on Ubuntu
---

* http://wiki.codeblocks.org/index.php?title=Installing_Code::Blocks_nightly_build_on_Ubuntu
