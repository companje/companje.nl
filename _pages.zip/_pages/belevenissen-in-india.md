---
title: Belevenissen in India
---
Kshitij 2008 is afgelopen nu. Het was geweldig. Op de eerste dag hebben we een lezing gegeven over Globe4D, daarna begon de expositie. Onze expositieruimte werd heel erg druk bezocht. Rijen dik aan mensen stonden buiten in een rij te wachten om naar binnen te mogen. Erg leuk om de Indiërs te vertellen en te laten zien hoe hun continentale plaat vanaf het zuiden van Afrika over de Indische oceaan richting Azië is gedreven en uiteindelijk door de botsing die 50 miljoen jaar geleden begonnen is volgens de theorie de Himalaya's heeft gevormd. Aan het eind van de tweede dag werden we gevraagd om in te vallen voor een grote act op het hoofdpodium. Toen hebben we binnen een uur de globe laten opbouwen op het hoofdpodium en de presentatie aangepast aan een publiek van 5000 studenten. Het ging echt heel erg goed! Vanaf dat moment werden we als celebs behandeld en hebben oneindig veel handtekeningen uitgedeeld en moesten steeds op de foto. We konden eigenlijk niet meer zelf lopen van A naar B want je werd continu staande gehouden dus moesten we steeds in een taxi over het universiteitsterrein. Erg maf.
 
(http://www.companje.nl/wp-content/uploads/2008/02/globe4d-lecture-kshitij-2008.jpg) 
 
Nu zitten we in Calcutta. Gisteren zijn we het centrum in geweest. Ik vond het wel een beetje te vergelijken met Tunesie qua kraampjes ed. Ik was voorbereid op veel koopmannen, oplichters en bedelaars maar Calcutta lijkt mee te vallen. Tunesie was 'erger' vind ik.

Het uitzicht van het guesthouse waar we nu zitten is wel minder. Het kijkt precies uit op soort van krottenwijk. Erg heftig om te zien hoe de mensen daar leven. Het grootste verschil tot nu toe vind ik dat en het verkeer. Als je je niet gewoon je volledig overgeeft en accepteert hoe ze hier rijden zou je helemaal panisch worden in de taxi. Het gaat bijna altijd goed maar alles gaat kriskras door elkaar heen en een claxon wordt echt op een totaal andere manier gebruikt dan in Nederland. De chauffeurs hier rijden met een hand aan het stuur en met een hand aan de claxon. Degene met het meeste lef heeft en krijgt voorrang.

Vandaag mogen we niet naar buiten want er zijn onrusten in de stad. Gisteren heeft de politie 4 mensen doodgeschoten tijdens een demonstratie en nu is er een bandh uitgeroepen. Dan blijft alles dicht en blijft bijna iedereen binnen een soort staking. We hebben net beelden gezien op tv van bussen die toch gingen rijden enzo en daar werd met stokken op ingeslagen enzo... best eng dus. We doen voorzichtig en volgen de instructies van de locals hier.

Over een paar dagen zijn we weer terug in Nederland. Waarschijnlijk is dat eerder dan onze globe want er gaat van alles mis met het binnenlands transport van de globe. Daarna binnen twee dagen weer door naar Italië. Gelukkig hebben we een reserve globe.



(tag>)


~~DISCUSSION~~
