---
title: Scratch
---
(and other educational visual programming tools)

* http://ericrosenbaum.github.io/BeetleBlocks/beetleblocks.html
