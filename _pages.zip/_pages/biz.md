---
title: https://baremetrics.com/blog/bootstrapped-to-funded
---

