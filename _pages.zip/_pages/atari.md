---
title: Atari
---
* [[https://medium.com/@thi.ng/the-jacob-s-ladder-of-coding-4b12477a26c1#.jw3udpuhk|mooi verhaal via de fb van Golan]]
* http://atariarchives.org/roots/
