---
title: Business
---
Tips van Nico:
* www.bhorowitz.com: Blog van venture capitalist Ben Horowitz, een kerel die steevast al z'n blogs begint met het linken naar een vers uit een rap lyric, iets waar hij groot fan van is. Schrijft interessante posts over businessmanagement
* [[https://www.youtube.com/channel/UCxIJaCMEptJjxmmQgGFsnCg|youtube link]]: De 'How to start a startup' series van Stanford waar tal van goede sprekers, waaronder bovenstaande, lectures doen over verschillende aspecten van het runnen en opzetten van een tech bedrijf.
* DONE: [[https://www.youtube.com/watch?v=uVhTvQXfibU|Les 15 - how to manage]] hoe om te gaan met werknemers, loonsverhogingen, ontslag en gevolgen voor cultuur etc.
* DONE: [[https://www.youtube.com/watch?v=dQ7ZvO5DpIw|Les 13 - how to be a great founder]] over de balans tussen angst en durf, ratio en gutinstinct, etc.
* Buffer app: Buffer is een heel leuk volledig gedistribueerd bedrijf van zon 25 man die naast het ontwikkelen aan de buffer app veel blog posts schrijven en cijfers over het bedrijf publiceren. Waarschijnlijk het meest transparante bedrijf in de wereld. Zij zijn er erg goed in geslaagd hun transparantie in te zetten om heel veel positieve media en word of mouth te genereren. Mogelijk gaan wij buffer zelf ook gebruiken om onze social media posts te doen. Ik sprak er vandaag over met Eva en zij gebruikt het toevallig zelf ook. Deze post bevat veel coole dingen: https://open.bufferapp.com/buffer-public-revenue-dashboard/
* http://blog.bufferapp.com: Rest van het blog is ook de moeite waard:

* http://www.bhorowitz.com/
* https://www.ycombinator.com/
* [[http://www.capriza.com/|capriza: Mobilize your existing business applications by next week]]
