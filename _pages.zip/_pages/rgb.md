---
title: RGB files
---
see also [[pgm]]

====Analyse RGB file with Processing====
%gist(a70fe3b13e6269b1238f)%
