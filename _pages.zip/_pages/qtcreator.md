---
title: QtCreator
---
see [[openFrameworks]], [[elementaryOS]]

=====Open Terminal Here in QtCreator on ElementaryOS=====
`Tools->Options->Environment->System` set the `Terminal` to `pantheon-terminal %d`
