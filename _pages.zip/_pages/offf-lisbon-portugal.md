---
title: OFFF 2008, Lisbon, Portugal
---
Currently I'm at the OFFF festival in Lisbon, Portugal. Enjoying the works of artists in motion graphics, information visualization and more.
\
(blog:offf.jpg?550|)

(tag>Flash Events)

~~DISCUSSION~~
