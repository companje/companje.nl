---
title: OCR
---
* http://www.free-ocr.com/
* http://projectnaptha.com javascript library en chrome addon voor OCR van plaatjes (tip v Simon)

=====OCRAD !!!!====
```bash
brew install ocrad
convert 14.16.12.png img.ppm
ocrad img.ppm > output.txt

#or
brew install netpbm
pngtopnm filename.png | ocrad


```
