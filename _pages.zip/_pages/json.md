---
title: JSON
---

==format json on osx terminal==
`brew install js`

==online json editor==
http://www.jsoneditoronline.org/

<code javascript>
    var url = "http://192.168.0.165/?jsoncallback=?";
</code>

==json formatter==
* http://www.bodurov.com/JsonFormatter/

==validate json==
* http://jsonlint.com/

==online yaml to json converter with colors==
*http://nodeca.github.io/js-yaml/
