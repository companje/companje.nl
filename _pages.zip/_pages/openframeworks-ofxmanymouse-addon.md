---
title: OpenFrameworks ofxManyMouse addon
---
I finished a first version of my [[:ofxManyMouse]] addon for [[:OpenFrameworks]]. It's based on the ManyMouse library by Ryan C. Gordon.

With this openFrameworks addon you can easily read values from multiple mouse devices. 

(  blog:2008.05.01-23.28-01.png?340|)You can find it here:
[[http://companje.nl/downloads/openFrameworks/ofxManyMouse/addon_ofxManyMouse.zip|download addon (200KB)]]  
[[http://companje.nl/downloads/openFrameworks/ofxManyMouse/ofxManyMouseExample.zip|download example app (6.5MB)]] (in Code::Blocks on Win32)

One things I really want to add in the future is event handling, being able to for example register for an onMouseDown event.

I hope it will be of use for you. Good luck!

(tag>Tech OpenFrameworks C++ Programming)

~~DISCUSSION~~
