---
title: APL
---
  * [[http://nl.wikipedia.org/wiki/APL_(programmeertaal)|nl.wikipedia over APL]]
  * [[http://www.dyalog.com/|dyalog]]
  * [[https://www.youtube.com/watch?v=_DTpQ4Kk2wA|APL demo 1975]]
  * [[https://www.youtube.com/watch?hl=en-GB&gl=GB&fmt=18&v=a9xAKttWgP4|game of life in APL]]
  * [[https://www.youtube.com/watch?v=DmT80OseAGs|sudoku solver in APL]]
  * [[http://en.wikipedia.org/wiki/APL_syntax_and_symbols|APL syntax and symbols on wikipedia]]
  * install gnu-apl on osx: `brew install gnu-apl`
  * [[http://tryapl.org/|online APL editor tryapl.org]]
