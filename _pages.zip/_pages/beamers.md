---
title: Beamers
---

* Groothoek wandprojectie Geofort: EIKI LC XSP 2600

* [[http://www.projectorcentral.com/Epson_Europe-EB-G6550WU-projection-calculator-pro.htm|epson short throw zoom lens]] (mogelijke oplossing ostrava)
