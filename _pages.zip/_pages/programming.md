---
title: Programming Languages
---

==Articles==
* https://medium.com/@thi.ng/the-jacob-s-ladder-of-coding-4b12477a26c1#.iobrtpj0n

==Some used languages==
*[[Batch]]
*[[Sanyo Basic]]
*[[QBasic]]
*[[MSX Basic]]
*[[Assembly]]
*[[Pascal]]
*[[Delphi]]
*[[C++]]
*[[Flash]]
*[[Flex]]
*[[Forth]]
*[[Java]]
*[[Processing]]
*[[HTML]]
*[[js|Javascript]]
*[[Visual Basic]]

==Want to learn==
*[[https://www.rust-lang.org/]]
*[[http://www.ponylang.org/]]
*[[https://golang.org/]]
*[[http://clojure.org/]]
