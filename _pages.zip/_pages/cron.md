---
title: Cron jobs
---

=====editor the list of cronjobs=====
  crobtab -e
  
=====restart cron service======
  sudo service cron restart
