---
title: Privacy
---
*https://www.youtube.com/watch?v=vILAlhwUgIU
*https://www.youtube.com/watch?v=Cu6accTBjfs
*https://www.youtube.com/watch?v=12OxkX3IVVo
*http://www.worm.org/home/view/event/11656

* [[http://new.livestream.com/bigbrotherawards/live/videos/71380878|Big Brother Awards 2014]]: je moeten fouten kunnen maken om te kunnen leren. Zonder 't vermogen om fouten te maken is er geen vrijheid.
