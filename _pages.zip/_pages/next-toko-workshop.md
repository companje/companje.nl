---
title: Next TOKO workshop
---
Next [[:TOKO/]] workshop will be at Wednesday 12th from 15h till 22h.

Last time we went into structural programming. We started with assembly code (by Maarten) soon followed by pointers (by Harmen) and ended with object oriented programming in c++ (by me) and did a lot in between.

Next session will be about existing libraries/toolkits (for ie. C++ or Processing) and how they help you not to re-invent the wheel.

Please come if you can. It can be very useful for your projects and there's very good food!

http://www.dewar.nl/toko

(blog:2008:03:workshop1.jpg?550)

(tag>Tech Programming)

~~DISCUSSION~~
