---
title: NL128.420.613.B01
---

==ex btw bedrag uitrekenen van inc btw bedrag==
<code>100 x inc / 121 = ex btw</code>
of
<code>inc / 1,21</code>

==kleine ondernemersregeling==
[[http://download.belastingdienst.nl/belastingdienst/docs/de_kleineondernemersregeling_ob2011z15fd.pdf|brochure]]  
Meer dan één onderneming? Hebt u meerdere eenmanszaken? Dan moet u de btw hiervan bij elkaar optellen, als u de belastingvermindering uitrekent. De regeling geldt namelijk voor u als ondernemer en niet per bedrijf. **In andere gevallen, bijvoorbeeld als u een eenmanszaak hebt en deelneemt aan een vof, hoeft u de bedragen niet bij elkaar op te tellen.**  

**Let op!**
De btw-vermindering leidt tot meer winst. Vergeet daarom niet bij uw 
aangifte inkomstenbelasting het voordeel van de btw-vermindering 
op te tellen bij uw resultaat
