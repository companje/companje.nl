---
title: IoT - Internet of Things
---

==Johnny-Five: The JavaScript LightBlue Bean Robotics & IoT Platform==
* example: http://johnny-five.io/examples/proximity-hcsr04/
