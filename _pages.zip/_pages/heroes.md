---
title: Heroes
---

===== Coding =====
* [[http://mrl.nyu.edu/~perlin/|Ken Perlin]]
* [[http://postspectacular.com/|Karsten Schmidt]]
