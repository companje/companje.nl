---
title: Robodock 2005
---
*[[http://picasaweb.google.com/rick.companje/Robodock2005|Photos of Robodock 2005 at PicasaWeb]]
