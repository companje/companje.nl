---
title: De Papierverscanneraar
---
De [[afstuderen:Papierverscanneraar]] is een nieuw apparaat: Een schredder met ingebouwde scanner, of een scanner met ingebouwde schredder, hoe je het maar bekijkt. De verscanneraar scant een papiertje (bijvoorbeeld een concertkaartje, boodschappenlijstje of foto) en transformeert het in één keer van fysiek tastbaar naar virtueel op internet. Het fysieke object wordt door het apparaat echt versnippert / vernietigd om de transformatie onomkeerbaar te maken. Je helpt het fysieke object letterlijk naar een andere wereld. Van de fysieke naar de virtuele. Is de herinnering nu nog net zo bijzonder nu je het niet meer kunt vastpakken?

(afstuderen:papierverscanneraar-1.jpg?550|Papierverscanneraar)
Tekening: [[people:Kris Kobes]]


(tag>)


~~DISCUSSION~~
