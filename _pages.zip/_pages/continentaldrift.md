---
title: see [[platetectonics|Plate Tectonics]]
---

