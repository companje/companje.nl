---
title: Portugal 2008
---
*Naar [[OFFF]] festival geweest in [[Lissabon]] met [[Ralph Kok|Ralph]] en het team van Random.nu
