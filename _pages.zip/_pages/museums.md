---
title: Museums
---

=== Museums exhibiting my work===
*[[Perot Museum of Nature & Science]] (Dallas, USA, 2011)
*[[Sterrenwacht Leiden]] (Leiden, Netherlands, 2011)
*[[Technoseum]], (Mannheim, 2011)
*[[Geological Museum of Yemen]] (Sana'a, Yemen, 2011)
*[[Max Liebermann Haus]], (Berlin, 2010)
*[[ScienceLinx]] (Groningen, Netherlands, 2010)
*[[Sintra Natural History Museum]] (Sintra, Portugal, 2009)
*[[National Gwacheon Science Museum]] (Seoul, Korea, 2009)
*[[Natuurhistorisch Museum Maastricht]] (Maastricht, Netherlands, 2008)
*[[Museum voor Beeld en Geluid]] (Hilversum, Netherlands, 2006)
*[[Rijksmuseum Amsterdam]] (Amsterdam, Netherlands, 2004)

===Museums visited===
*Paris: Cité des sciences
*Los Angeles: Science Centre
*Los Angeles: Museum of Natural History
*Santa Barbara: Museum of Natural History
*San Fransisco: Exploratorium
*San Francisco: California Academy of Science
*San Jose: The Tech
*Ithaca: Museum of the Earth
*New York Hall of Science
*New York: American Museum of Natural History
*Utrecht: Sterrenwacht Sonnenborgh
*Utrecht: Universiteitsmuseum
*Nemo Amsterdam
*MOMA New York
*Rijksmuseum Amsterdam
*Kroller Muller
*Naturalis
*Veel musea in Nieuw Zeeland
*Groninger Museum
*Kunsthal Rotterdam
*Booijmans van Beuningen Rotterdam
*Haags Gemeentemuseum
*TomTits Experiment
*..... nog verder aanvullen

===Musea waar ik zeker nog naar toe moet===
*[[Phaeno]] in [[Wolfsburg]]
*..... nog verder aanvullen
