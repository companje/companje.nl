---
title: Lancering Flex User Group
---
Lancering Flex User Group (FLUGR) - eerste meeting 13 juni 2008

De eerste meeting van de Nederlandse Flex User Group vindt 13 juni plaats. De User Group is bedoeld voor Flex- en AIR developers die kennis willen delen en inspiratie opdoen over deze onderwerpen, maar ook over BlazeDS en Actionscript 3. Op deze eerste meeting zullen internationale Flex-guru's spreken.

Tijdens deze meeting zullen Benjamin Dobler en Stephan Janssen vertellen over hun ervaringen met het omzetten van een Java website (http://www.parleys.com) waar meer dan 10Tb aan streaming video's op staan naar een Flexsite. Daarnaast is er een Air applicatie gemaakt waarbij ook alles offline werkt: Benjamin en Stephan demonstreren de site en de gebruikte technieken. Nicolas Lierman zal daarna zijn Google Analytics tool zien, die voor velen een voorbeeld is om over te stappen naar AIR. Christophe Herreman gaat in op het project Prana, een framework voor het ontwikkelen in Actionscript. Aansluitend is er een borrel met de mogelijkheid tot het stellen van vragen aan de sprekers en enkele Adobe-specialisten.

Meetings en inschrijven
Doel van de Flex User Group (FLUGR) is om jaarlijks een aantal meetings te organiseren, waarbij er aansprekende lezingen of workshops zijn, kennis gedeeld kan worden (ook middels het forum op de site) en het actief aanbieden van het laatste nieuws rond Flex. Leden van FLUGR hebben daarme toegang tot de enige echte Nederlandse Flex community, de meetings, netwerkborrels, kennis en inspiratie en ontvangen de nieuwsbrief. Lid worden is gratis en kan op www.flugr.nl, waar ook aanvullende info over de meetings is te vinden.

Het evenement vindt 13 juni van 13.30 uur tot 18.00 uur plaats in Kasteel ter Horst, Loenen (Apeldoorn). Inschrijven is verplicht en dat kan gratis op www.flugr.nl.

(tag>Flex)


~~DISCUSSION~~
