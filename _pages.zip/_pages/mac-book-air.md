---
title: Mac Book Air
---
Oeeew, wordt ik misschien toch nog een Mac gebruiker? Wat is dit verleidelijk zeg... Zie het artikel op [[http://www.bright.nl/dunste-notebook-ter-wereld-macbook-air|bright.nl]] 

In Euro kost ie 1699, in dollars 1799 ex 8% VAT. Oftewel (1799 + (8% van 1799)) = 1942 US dollar = 1320 euro. Is dus wel de moeite om 'm daar te halen... moet je geen pech hebben bij de douane...

(youtube>large:W7askBmF4_c)

Zie hier de specs op [[http://www.a-mac.nl/amac/component/page,shop.product_details/flypage,shop.flypage/product_id,516/category_id,1/manufacturer_id,0/option,com_virtuemart/|a-mac.nl]]
(tag>Design)

~~DISCUSSION~~
