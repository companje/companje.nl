---
title: Laval Virtual 2007
---
[[Globe4D]] has been exhibited at [[Laval Virtual 2007]] in France in [[April 2007]].

<blockquote>( http://www.companje.nl/wp-content/uploads/2007/02/laval-virtual-ReVolution-2007.jpg)Laval Virtual 2007, one of the biggest European Virtual Reality conventions, will be held at 18th-22nd April. A new demonstration session, “ReVolution” was successfully started at last edition.

Laval Virtual ReVolution is an annual honor to the world's finest VR project, by Laval Virtual. This is a hall of fame award that decides the best Virtual Reality demonstration and/or application from all over the world. Virtual Reality is not only a technology but also a never ending story between computers and human history.</blockquote>

<blockquote>
**LAVAL VIRTUAL 2007 - APRIL 18-22, 2007, LAVAL, FRANCE**

Laval Virtual 2007, one of the biggest European Virtual Reality conventions. Laval Virtual ReVolution is an annual honor to the world’s finest VR projects. This is a hall of fame award that decides the best Virtual Reality demonstration and/or application from all over the world.

At Laval Virtual 2007 we released a new version of [[Globe4D]]. This event in the west of France attracted over 10.000 people with all kinds of backgrounds: scientists, engineers, museum directors, school teachers, children from all ages, parents and grandparents. Exhibiting at Laval Virtual gave us the opportunity to test our four dimensional globe on a really big user group. Thousands of people enjoyed playing with Globe4D and learned about the history of the earth.</blockquote>

[[http://www.laval-virtual.org]]

(tag>Globe4D Events)
