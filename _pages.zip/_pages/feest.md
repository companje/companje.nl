---
title: Feest!
---
Hallo allemaal!

Volgende week maandag 15 december ben ik jarig. Daarom en omdat ik al weer een paar maanden in het mooie Katwijk woon geef ik een feestje.
Het wordt een bijzonder feest want het duurt het hele weekend (vanaf vrijdagavond de 12e t/m zondagavond de 14e). Een soort Woodstock dus... maar dan in Katwijk.

<blockquote>Het Woodstock Music and Art Festival was een rockfestival dat in het weekend van 15, 16 en 17 augustus 1969 plaatsvond op een weideveld van de melkveehouder Max Yasgur in Bethel, New York, zo'n 65 km buiten Woodstock. Het festival, onder het motto "three days of peace and music", wordt door velen beschouwd als het beroemdste muziekfestival ooit.

Hoewel tien- tot twintigduizend mensen werden verwacht, lag het uiteindelijke bezoekersaantal ruim boven de 400.000 (sommigen beweren zelfs een miljoen), waarvan de meesten geen entreegeld hadden betaald. Daarnaast waren nog eens drie miljoen mensen naar het terrein onderweg. Hierdoor was het festival initieel niet winstgevend voor de organisatoren (promotors), maar dankzij de platenverkoop en inkomsten van de film werd het dat uiteindelijk toch nog.

Ondanks de vele regen en de consumptie van alcohol en drugs was er betrekkelijk weinig misdaad en geweld op het festival. Er waren echter te weinig voorzieningen getroffen voor het onverwacht grote aantal bezoekers, waardoor Woodstock op de tweede dag tot rampgebied werd verklaard en de hulp van het leger werd ingeroepen. Het Woodstockfestival was een hoogtepunt van de tegencultuur van de jaren '60 en van het hippietijdperk.

Er vielen drie doden; een door een overdosis heroïne, een doordat hij in slaap gevallen was en door een traktor werd overreden en een door een acute blindedarmontsteking. Daarnaast werden er tijdens het festival twee baby's geboren.</blockquote>

Nu hoop ik van harte dat er geen 400.000 mensen naar Katwijk komen, dat heb ik ook plechtig aan de gemeente beloofd, maar omdat het toch het hele weekend duurt en vast niet iedereen het de volle 48 uur volhoudt mag je je vriendje of vriendinnetje meenemen (tenzij ze op het punt staat te gaan bevallen in mijn woonkamer).

Hoewel het nu lijkt dat Woodstock het hoofdthema van het huisverwarmings-verjaardagsweekend is had ik aanvankelijk het plan er juist een VPRO / Villa Achterwerk weekend van te maken. Dat wil dus zeggen: Heb je nog oude videobanden en/of dvd's van Villa Achterwerk programma's, of KRO's Heksennest cassettebandjes neem deze dan vooral mee. Denk aan De grote dikke beer vertelt, Purno de Purno, Achterwerk in de Kast, Apie van de Hoek, Kinderbevrijdingsfront, Babar, Lekker Dansen, Theo en Thea, Buurman en Buurman, Madelief, De Freules, Buurman Bolle, Mevrouw Ten Cate, Ojajoh!, White Cowboy, Rembo en Rembo, futiliteitenmuseum, Pinkenplace en natuurlijk Pingu.

Neem ook vooral slaapzakken mee en als je ze hebt matjes. Ik heb wel een paar extra matrassen maar misschien wordt het toch té Woodstock als we daar allemaal opkruipen. Verder gaan we ook fijne strandwandelingen maken dus neem een dikke jas mee als je daar wat voor voelt.

Qua vervoer. Er stoppen talloze bussen recht voor mijn duur die je vanaf Leiden of Den Haag kunt pakken. Zoek het vooral even zelf uit via 9292ov.nl. Mocht je met de auto willen komen, er is vollop gratis parkeergelegenheid (dat is dan weer wel een voordeel van Katwijk). Met de traktor mag ook mits je geen slapende feestgangers overrijd. Mijn adres staat onderaan de mail.

O ja, en voor de non-native Nederlanders: There's a party at my place between December 12th and 14th. Please come!

Jeuj! Tot vrijdag/zaterdag en/of zondag! Laat even weten of je komt, met hoeveel vriendjes en vriendinnetjes en hoeveel maaltijden je bijwoond.

Groetjes Rick

Zeewoldtstraat 10
2223 ET Katwijk ZH
telefoon: 06 2851 6908

(tag>Fun)


~~DISCUSSION~~
