---
title: Hex editors
---
* prima maar antieke hex viewer/editor: [[http://www.chmaas.handshake.de/delphi/freeware/xvi32/xvi32.htm#download|xvi32]]
* [[http://www.suavetech.com/0xed/0xed.html|0xED]] for osx 
* [[http://ridiculousfish.com/hexfiend/|hexfiend]]
