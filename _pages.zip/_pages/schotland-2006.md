---
title: Schotland 2007
---
(youtube>large:lh-6WOc4Ejw)

(tag>Travel)
