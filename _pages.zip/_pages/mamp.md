---
title: Mamp
---

* [[http://ampps.com/download|AMMPS is MAMP alternative]]
