---
title: O!? Morgen?
---
Gisteravond werd ik ineens gebeld door Joost van Cinekid of ik tijdens het GameJam weekend een (Java/Flash-) gameconcept voor de mobiele telefoon zou willen helpen te ontwikkelen... of ik mee ging doen. O!? Morgen? Ok...
 
[[http://japangamejam.blogspot.com/
|(blog:2008:03:moppy.gif|)]]
 
http://japangamejam.blogspot.com/
 
<blockquote>
( blog:2008:03:cibil.jpg)Een Nederlandse mobiele game voor de Japanse markt
 
Om Nederland in Japan te promoten hebben de Nederlandse Ambassade in Tokio, de Dutch Game Garden en de stichting NLGD besloten een Nederlandse mobiele game te laten maken voor de Japanse markt. Hiervoor zijn wij op zoek naar de beste Nederlandse game developers. Gaat jouw game straks Nederland in Japan vertegenwoordigen tijdens de TGS 2008?
 
De zoektocht
 
De eerste ronde in onze zoektocht is op 8 en 9 maart tijdens de nationale `Japan GameJam' in Utrecht, georganiseerd door de stichting NLGD en de Dutch Game Garden. De opdracht is om tijdens dit GameJam weekend een (Java/Flash-) gameconcept voor de mobiele telefoon te ontwikkelen.
Aan het begin van de GameJam zal Marc Wesseling informatie geven over Japan, de Japanse mobiele game markt en de gebruikte technologieën. Marc Wesseling ontwikkelt met zijn in Tokyo gevestigde bedrijf UltraSuperNew communicatiestrategieën voor digitale media en kan als geen ander inzicht geven in de Japanse markt van mobile games. Aan het einde van de GameJam kiest een vakjury de drie beste concepten uit.
 
Deze drie teams krijgen vervolgens drie weken de tijd om een playable demo te maken. Naar aanleiding van deze demo bepalen de vakjury en de Ambassade welke game Nederland in Japan vertegenwoordigt tijdens de Tokyo Game Show 2008.
 
Achtergrond
 
Twee belangrijke officiële festiviteiten staan aan de basis van deze Nederlandse mobiele game in Japan. In 2008 vieren Japan en Nederland 150 jaar diplomatieke relaties en volgend jaar, in 2009, vieren beide landen 400 jaar handelsbetrekkingen. De game gaat deel uitmaken van de officiële Nederlandse festiviteiten in Japan, dus de eisen zijn hoog! [[http://www.nieuwsbank.nl/inp/2008/02/28/G003.htm]]</blockquote>

(tag>)

~~DISCUSSION~~
