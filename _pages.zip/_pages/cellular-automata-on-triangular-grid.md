---
title: Cellular Automata on Triangular Grid
---
Together with [[::Joris Slob]] I experimented with a [[http://en.wikipedia.org/wiki/Cellular_automaton|cellular automaton]] on a triangular grid. A next experiment will be to do the same for a hexagonal grid which we will be mapping onto a sphere to incorporate this in [[Globe4D::|Globe4D]].
\
[[http://companje.nl/processing/Triangular-Game-Of-Life/|Demo and source code]].
\
[[http://companje.nl/processing/Triangular-Game-Of-Life/|(:blog:2009:08:triangular-cellular-automata.gif)]]


(tag>Math Tech Processing)


~~DISCUSSION~~
