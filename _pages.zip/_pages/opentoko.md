---
title: OpenToko.org
---

OpenToko.org is een kennis uitwisselingsnetwerk waardoor workshops worden georganiseerd over o.a. kunst en techniek.
\
Als kunstenaarscollectief De Spullenmannen bedachten dat we voor de projecten die we doen regelmatig nieuwe (vaak technische) kennis nodig hebben over zaken waar we zelf nooit voor hebben geleerd maar waar mensen in ons netwerk misschien wel expert in zijn. We zijn toen open workshops gaan houden over onderwerpen waar we zelf wat aan hadden, met sprekers die we meestal persoonlijk kenden en met een groeiende groep van geïnteresseerden die de workshops kwamen bij wonen. Bij iedere OpenToko workshop vragen we alle bezoekers in welk gebied zij expert of liefhebber zijn en of ze daar een volgende keer een workshop of praatje over kunnen geven. Op die manier kan iedereen kennis komen halen en brengen.
\
Regelmatig vinden de OpenToko workshops plaats in het kantoor of de werkplaats van een van de deelnemers. Daarnaast worden ze ook vaak gehouden in het Cultureel Verzamelkantoor van De War in Amersfoort of bij FabLab Amersfoort.
\
Iedereen is welkom en wordt geacht zijn of haar kennis te delen, wat overigens niet betekent dat je veel ervaring moet hebben om mee te kunnen doen. Maar als er een onderwerp is waar je veel over weet dan horen we het graag zodat we je kunnen vragen (een deel van) een volgende OpenToko workshop vorm te geven.
\
De workshops zijn niet gesubsidieerd. We vragen iedereen om een donatie te doen voor het eten en voor wat de kennis die je hebt opgedaan je waard is.
\
OpenToko.org is een initiatief van [[Rick Companje]], [[Diana Wildschut]] and [[Harmen Zijp]].

====== Links to this page ======
(backlinks>.)
