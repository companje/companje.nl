---
title: Power blocks
---
* http://www.amazon.de/XTPower%C2%AE-MP-10000-Powerbank-Ladeger%C3%A4t-Ladeadapter/dp/B006N48VJY
