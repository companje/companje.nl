---
title: Sass
---

=====!default=====
using Sass !default is like adding an “unless this is already assigned” qualifier to your variable assignments.
