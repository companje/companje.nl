---
title: Celebral
---
* http://github.com/christianalfoni/cerebral
* see [[redux]]
