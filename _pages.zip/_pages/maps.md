---
title: Maps
---
* [[http://qgis.org/en/site/about/index.html|QGIS]]
* https://www.shipmap.org/
* [[http://csmres.jmu.edu/Geollab/pyle/GEOL272/398%20images/|planet textures]]
* [[http://gizmodo.com/see-the-exact-moment-when-the-worlds-biggest-cities-wer-1782106715#_ga=1.32999102.1802093165.1454050536|birth of big cities]]
* [[http://cpgeosystems.com/rect_globe.html|ron blakey paleo maps]]
* https://commons.wikimedia.org/wiki/Publicly_available_global_data_sets
* [[http://www.soest.hawaii.edu/pwessel/gshhg/|A Global Self-consistent, Hierarchical, High-resolution Geography Database (GSHHG)]]
* http://www.earthbrowser.com/
* http://www.blenderguru.com/tutorials/earth-cycles/
* http://www.earthbyte.org/ ("building a virtual earth")
* https://decolonialatlas.wordpress.com/
* https://www.nsof.class.noaa.gov/data_available/npp/npp_ftpserver.htm

* http://tegenlicht.vpro.nl/bijlagen/2015-2016/een-paar-graden-minder/kaarten.html
* micromappers
* https://storymap.knightlab.com/
* cartodb
* http://battles.nodegoat.net/viewer.p/23/385/scenario/1/geo/fullscreen
* http://www.supinemusic.net/Files%20for%20Cloud%20projects/Cinema%204D/plugins/Planet%20X%20Generator%20R12/presets//

==klimaat==
https://commons.wikimedia.org/wiki/File:K%C3%B6ppen-vereinfacht.svg
