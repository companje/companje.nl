---
title: Media Tech Expo
---
(  :blog:ttext.png?200|)New Media New Technology 2011
Open Lab Expo
Tuesday May 31, 2011
4pm-9pm.
Scheltema Complex - Marktsteeg 1, Leiden
 \
Nieuwe media, kunst, wetenschap en technologie komen samen in de New Media New Technology (NMNT) Open Lab Expo van master studenten Media Technology van de Universiteit Leiden. De studenten tonen halffabrikaten en eindproducten van het vak NMNT dat de laatste New Media technologieen en concepten combineert met meer tijdloze themas als New Media History, Old Media, Social, Mobile, Things & Space.
 \
De expo is niet een traditionele statische expositie, maar meer een dynamisch  ‘Open Lab’ oftewel een open werkplaats. Veel van de installaties zijn interactief en zijn exploratieve vingeroefeningen die nieuwsgierig maken naar meer. Alle makers zijn aanwezig om vragen te beantwoorden en van gedachten te wisselen over de concepten, gedachten en technologieen achter hun werk, en soms kan er ter plekke verder geklust worden. Iedereen is welkom, met maar nadrukkelijk ook zonder nieuwe media achtergrond.
 \
Nieuwsgierig? Kijk op [[http://www.nmnt.nl]] voor voorbeelden van projecten en op [[http://mediatechnology.leiden.edu/]] voor meer informatie over the MSc Media Technologie als opleiding voor Creative Research. 


(tag>Events Study Tech Art)


~~DISCUSSION~~
