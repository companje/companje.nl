---
title: Midi
---
* [[http://www.m-audio.com/support/download/drivers/midi-usb-driver-v3.5.3-mac1|David's M-AUDIO USB MIDIsport 2x2 (driver)]]
* [[http://www.manyetas.com/creed/midikeys.html|small tool for testing MIDI]]
* MIDI input to Arduino. See [[Arduino]]
* http://www.midi.org/techspecs/midimessages.php
