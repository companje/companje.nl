---
title: DisplayPort
---
* tip v Olaf: http://www.displayport.org/cables/driving-multiple-displays-from-a-single-displayport-output/
