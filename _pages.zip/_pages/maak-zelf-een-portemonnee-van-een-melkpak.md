---
title: Maak zelf een portemonnee van een melkpak
---
In het onderstaande filmpje leg ik uit hoe je van een melkpak een portemonnee kunt maken.
 
(youtube>large:UWfm4uneVv4)

(tag>)


~~DISCUSSION~~
