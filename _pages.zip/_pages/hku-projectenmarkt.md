---
title: HKU Projectenmarkt
---
Op donderdag 21 januari 2010 presenteren vierdejaarsstudenten op de projectenmarkt van de Faculteit Kunst, Media & Technologie de resultaten van de groepsprojecten die ze de afgelopen maanden voor externe opdrachtgevers hebben uitgevoerd. 

Met een collectie van bijna 40 innovatieve en creatieve studentenprojecten geeft de projectenmarkt een actueel overzicht op het gebied van game design, interactie, animatie, muziek en geluid, cross media-producties en documentaires.
 
Waar en wanneer?
Datum: Donderdag 21 januari
Tijd: 14.00 - 20.00 uur
Locatie: Faculteit Kunst, Media & Technologie (KMT), Oude Amersfoortseweg 131, 1212 AA Hilversum

[[http://www.hku.nl/web/show/id=107916|(:blog:hku-e-banner.jpg|)]]

[[http://www.hku.nl/web/show/id=107916|Meer informatie]] op de website van de HKU

(tag>Art Media Tech Events)


~~DISCUSSION~~
