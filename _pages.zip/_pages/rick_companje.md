---
title: Rick Companje (1979) likes to explore the space between art, science and technology. With a background in Computer Science, Interaction Design and Media Technology and working as a media artist and inventor, Rick Companje tries to combine the forces of his favorite disciplines.
---
His recent work includes [[:Globe4D]], an interactive physical globe with time as extra dimension showing in a very direct and intuitive way how a planet changes over time. Another notable project is the Interactive Historical Timeline for [[:Rijksmuseum Amsterdam]] (Royal Museum of Art).
Companje's work has been exhibited at [[:Laval Virtual]], [[:ACM Siggraph]], [[:Wired Nextfest]], [[:Cinekid]] and [[:TodaysArt]].
