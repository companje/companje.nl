---
title: Admin Panels
---
* http://ajenti.org/
* OpenPanel (not maintained)
* http://ehcp.net/
* http://sentora.org/
* http://www.froxlor.org/
* http://www.ispconfig.org/page/home.html
* [[Vesta Control Panel]] (http://vestacp.com/)
