---
title: iPhone cursus @ Universiteit Leiden
---
Samen met Bas Haring verzorg ik op 9 en 16 april de gratis iPhone cursus @ Universiteit Leiden. Je kunt je niet meer opgeven helaas. De belangstelling was zeer groot, zo'n 500 aanmeldingen! . Wel staan er slides online van mijn deel van de cursus: [[http://iphone.opentoko.org]]. Binnenkort geef ik nog een paar iPhone workshops waaronder een op [[http://www.setuputrecht.nl/|SETUP Utrecht]] en ook een in de vorm van een [[http://www.opentoko.org|OpenToko]] dus wil je mee doen laat dan een berichtje achter en ik stel je op de hoogte zodra ik de datum/tijd en exacte locatie weet.




(tag>)


~~DISCUSSION~~
