---
title: ASCII (and other character sets)
---

=====search for html entities=====
* http://www.amp-what.com/

===== subset of characters =====
<code>
!"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~
</code>

=====ASCII logo / tags=====
http://patorjk.com/software/taag

===== picture to ascii =====
http://picascii.com/

===== draw ascii art online =====
http://asciiflow.com/

===== interesting characters =====
█▓▒░
