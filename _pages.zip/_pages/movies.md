---
title: Movies
---

=====TODO======
* https://www.youtube.com/watch?v=LLRweyZ1KpA (ARKit iOS)
* https://www.youtube.com/watch?v=BOrg2oc3-rQ
* https://youtu.be/xhQ7d3BK3KQ
* 20th century woman - tip van Dominic
* guardians of the galaxy 2
* Swiss army man (tip v Nico)
* goed filmpje over neural networks: https://youtu.be/ILsA4nyG7I0
* Ghost in the shell (kijken in Kinepolis)
* DONE: Toffe korte video over machine learning: https://youtu.be/qv6UVOQ0F44
* DONE: passengers
* life (tip v Jeroen)
* DONE: hotfuzz (tip v Casper)

==Find my phone==
* DONE http://thenextweb.com/mobile/2016/12/16/film-student-tricked-thief-lifting-phone-spied-weeks/

==tip v radio==
* The Circle (11 May 2017)

==tip v Jeroen en Peter==
* DONE: Arrival

==tip v David==
* [[https://www.youtube.com/watch?v=SGJ5cZnoodY|Shenzhen: The Silicon Valley of Hardware (Full Documentary) | Future Cities | WIRED]]
==tip van Peter==
* dr Strange (in 3d bios kijken)
* https://www.youtube.com/watch?v=SGJ5cZnoodY

==tip van Dirk (lezing kivi)==
* https://www.youtube.com/watch?v=r-gLOwilm_A

==tip van Jeroen==
* UP - animatiefilm van een man die met ballonnen aan z'n huis de wereld rond vliegt

==tip van Peter==
* In de docu Racing Extinction zit rond 11:00 een korte maar hele mooie wereld geschiedenis animatie. Misschien interessant om te kijken wie die hebben gemaakt?
* DONE https://blog.sketchfab.com/add-another-layer-realism-depth-field/

==tip van Hilde==
* https://www.youtube.com/watch?v=fxbCHn6gE3U
* [[https://www.youtube.com/watch?v=gUlc1-e11EE|Ronja de Roversdochter]]

==tip van Gerard==
* DONE: [[http://www.npo.nl/zoeken?utf8=%E2%9C%93&q=matterhorn|Matterhorn]]
* jim van der woude jiskefet amnesty

==draait nu in het Eye==
https://www.eyefilm.nl/film/the-land-of-the-enlightened-0?program_id=11784667

==tip van mezelf uit nz 2005==
* goodbye pork pie
* Whale Rider
* Once we were warriors

==tip van Hilde==
* Puberruil XL 10 jaar - Nico vs Akwasi
* DONE The Grand Budapest Hotel

==tip van Mesut==
* DONE Castaway on the moon
* Memories of a murderer
* DONE: Somewhere Else Tomorrow (tip!)

==tip from Kris Black==
* Weird Science (80s classic)

==live coding tips van peter==
* [[https://vimeo.com/20241649|docu]]
* [[https://www.youtube.com/watch?v=GSGKEy8vHqg|Vet voorbeeld van live coding: Andrew Sorensen at TEDxQUT]]

==mad men==
[[http://www.imdb.com/title/tt0804503/|Mad Men]]

==tips van Marijn==
* Marsch of the pinguïns
* Chimpansee film Bert Haanstra

==Casper==
* The Inside Job (docu bankencrisis)

==tip van iedereen==
* DONE: Cabin in the woods

==tip van Toon==
* DONE: Mr Robot (serie over hacker)

==tip van Arne==
* citizen4 over Edward Snowden

==tip van ramon==
* Print the Legend 

==tips van peter==
* https://decorrespondent.nl/3210/De-oorlog-in-Syrie-uitgelegd-in-vijf-minuten/308948940960-f6545b45
* [[https://www.youtube.com/watch?v=TK1mBqKvIyU|Sonic PI TED lezing]]
* DONE: kung fury
* DONE: The Martian
* The Big Short

==tip v gerard==
* nanelle (zus van mozart)

==tips van sylvain==
* wolf
* !simon
* !broken circle breakdown
* DONE: guardians of the galaxy
* DONE: the immitation game (over alan turing)
* DONE: theory of everything (stephen hawkins)
* DONE: serie: black mirror
* whiplash

==tip van pedeka==
* DONE: kingsman

==tips van Ralph==
* DONE: predestination
* zero theorem
* under the skin (langzaam, duister, grauw)
* DONE: her (!)
* true romance
* neighbours
* DONE: [[http://m.imdb.com/title/tt0434409/|V for Vendetta]] wow!
* DONE: birdman
* inherent vice
* the final member (docu)
* Jiro dreams of sushi
* springbreakers

== tip van Nico ==
* nightcrawler

==tip van sasj==
Sonic Highways docu over foofighters.

==NL==
* nena
* DONE: aanmodderfakker
* hemel en aarde

==Diversen==
* the anchorman
* tip uit de Estafette Loper: gezinsfilm 'Un film de wouf' met Renault Estafette(s)
* DONE: Her (tip van Nanda)
* DONE: En man som heter Ove (tip van Jos)

==Films van Tom Tykwer==
* http://nl.wikipedia.org/wiki/Tom_Tykwer
* [[https://www.youtube.com/watch?v=D4Xcp9F5Nuc|the international]]
* [[https://www.youtube.com/watch?v=UW4OE1egbHs|a hologram for the king]]

==Mooi==
* DONE Mr Nobody
* DONE Le tout nouveau testament
* DONE Hanna
