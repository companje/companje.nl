---
title: ATxmega32C4
---
Microcontroller in the Micro3D printer.

http://www.atmel.com/devices/ATxmega32C4.aspx
