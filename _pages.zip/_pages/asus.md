---
title: Asus K53Z laptop
---

* After installing Windows 10 you need to install `Chipset_AMD_Compal_Win7_64_Z121321` (PNPINST64.EXE) to get DVD GT51N back to work.

* After installing Windows 10 you need to install `Chipset_AMD_Compal_Win7_64_Z890300000` drivers.

* After installing Windows 10 you need to reinstall `SAMSUNG_USB_Driver_for_Mobile_Phones.zip` (15.3MB) to recognize MTP USB-apparaat (Samsung Galaxy)

* On windows 10 when movies cause any movie player to crash install another version of the Graphics Driver. This one worked for me: http://www.driverscape.com/manufacturers/asus/laptops-desktops/k53z/585. Choose 
Device Name:	AMD Radeon(TM) HD 6520G, Driver Date	2012-08-28	File Size:	52.2M, Driver Version:	8.982.10.0000
