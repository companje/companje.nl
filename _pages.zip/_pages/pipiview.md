---
title: PiPiView
---

[[http://album.zoom.nl|ZOOM]], Nederlands eerste magazine over digitale fotografie en video, gebruikt mijn open source PiPiView polaroid viewer voor de persoonlijke web fotoalbums van hun lezers!

[[http://album.zoom.nl|(http://companje.nl/images/PiPiView.Zoom.nl.png)]]

[[http://album.zoom.nl]]

Bekijk hier een willekeurig voorbeeld van [[http://album.zoom.nl/user/adby/Wintersneeuw/polaroids|PiPiView op iemands fotoalbum]]
