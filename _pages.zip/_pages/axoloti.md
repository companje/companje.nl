---
title: Axoloti
---
* Harmen: "snel en makkelijk een stand-alone DSP-hardwaretoepassing mee bouwen, bv een synthesizer of effectpedaal, m.a.w. alles wat met MaxMSP of PureData kan, maar dan in een doosje dat direct opstart als je stroom op zet."

* David: "werkt ook op STM32F4DISCOVERY"
