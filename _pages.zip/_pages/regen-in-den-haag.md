---
title: Regen in Den Haag
---
Dat de iPhone geen scherpe foto's maakt is bekend maar sfeervol zijn ze wel. Een foto van de zon die doorbreekt op het Spui in Den Haag na een heftige regenbui.
(blog:iphone-den-haag-bij-regen.jpg?550|Regen in Den Haag )

(tag>Photos)


~~DISCUSSION~~
