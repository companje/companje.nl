---
title: Github
---

=====use image in markdown=====
<code>
![](doc/images/my-image.jpg)
</code>

=====github flavored markdown formatting=====
* https://help.github.com/articles/github-flavored-markdown/
* https://guides.github.com/features/mastering-markdown/

===== tips =====
* Updated in the last three days: updated:>2015-06-19.

===== issues =====
* https://help.github.com/articles/searching-issues/

===== Managing GitHub projects=====
* https://www.lullabot.com/articles/managing-projects-with-github
* https://waffle.io
* https://robinpowered.com/blog/best-practice-system-for-organizing-and-tagging-github-issues/
* http://huboard.com
* http://sweepboard
