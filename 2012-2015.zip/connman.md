---
title: Connman
---

==check network status==
  connmanctl technologies
  connmanctl services
  
==ctl==
  connmanctl
    help
    tether wifi on
