---
title: Wired NextFest 2007
---
=== SEPT. 13-16, 2007, LOS ANGELES ===

[[Globe4D]] has been exhibited at [[Wired Nextfest 2007]] in San Diego, California in [[September 2007]].

<blockquote>( events:wired-nextfest-2007.png|Globe4D at Wired Nextfest 2007)WIRED Magazine is bringing its vision of a new world’s fair to Los Angeles. Experience more than 160 exciting exhibits from scientists, researchers, and inventors around the globe. WIRED NextFest features innovations in communication, design, entertainment, exploration, health, play, robots, transportation, security, and green living.</blockquote>

http://www.wirednextfest.com
(tag>Events Globe4D)
