---
title: socket.io
---

=====debug socket.io messages in the browser=====
  localStorage.setItem("debug","socket.io-parser"); //or * etc...
