---
title: Stylus
---
Peter:
De pen die ik heb gekocht:
http://www.adonit.net/jot/mini/
Grotere versie:
http://www.adonit.net/jot/pro/

De volgende is waarschijnlijk minder fragiel, maar ik weet niet hoe dit werkt zonder een "ready" app. Al staat nergens dat het niet werkt bij niet "ready" apps. 
http://www.adonit.net/jot/script/

Replacement disks (oef $6,-): 
http://www.adonit.net/parts/replacement-discs/
