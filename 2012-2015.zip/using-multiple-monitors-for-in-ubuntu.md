---
title: Using multiple monitors for in Ubuntu
---
* http://ubuntuforums.org/showthread.php?t=221174
* for nvidia: 
```gksudo nvidia-settings```
