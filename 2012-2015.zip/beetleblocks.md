---
title: Beetle Blocks
---
* http://beetleblocks.com
* [[https://twitter.com/search?f=tweets&vertical=default&q=%23beetleblocks&src=typd|tweets]]
* [[http://tinkering.exploratorium.edu/tags/beetleblocks|blog posts by Exploratorium]]
* [[http://joshburker.blogspot.nl/2015/05/programming-organic-shapes-in-beetle.html|example generate shells]]
* [[http://web.media.mit.edu/~ericr/|Eric Rosenbaum's page]]

questions:
* what does 'Warp' do?
