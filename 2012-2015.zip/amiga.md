---
title: Amiga
---
* http://nl.wikipedia.org/wiki/AmigaOS
* http://wiki.classicamiga.com/Formatting_a_720KB_Double_Density_Floppy_Disk_in_XP/Vista
* [[http://m1web.de/ADTWin/|ADTWin]]: ADTWin to write floppies for Amiga from WinXP using a regular 3.5" floppy drive connected to parallel-port with self-made cable.
* When booting from floppy press left+right mousebuttons to get boot menu.
