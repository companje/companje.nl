---
title: TAR
---

==tar without compression==
```tar cf backup.tar folder```

==to tar a folder (with all subfolders and files):==
```tar czf backup.tgz thefolder```

==to untar a file==
```tar xvzf file.tar.gz```
