---
title: Making Electronic Thingies in Amsterdam
---

<blockquote>Meta (Making Electronic Thingies in Amsterdam) is sort of a self-help group for artists, designers & other (normal) people with an interest in electronics.</blockquote>

<blockquote>META members are artists, students, teachers and professionals in all kinds of disciplines like: Art, Multimedia, Interface- Graphic- Audio- and Web Design, Music Composition, you name it.
Others are simply interested without belonging to one of these categories.</blockquote> 

[[http://www.makingelectronicthingiesinamsterdam.nl]]

I attended a workshop here on [[electronics:Forth TV]] in [[dates:2007]] and visited some of the monthly meetings where in one of them [[http://fritzing.org|Fritzing]] was presented.
