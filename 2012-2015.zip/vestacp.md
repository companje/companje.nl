---
title: Vesta Control Panel
---
http://vestacp.com/

(Ubuntu 15.04 not supported currently 2015-09-5)

==Install==
```bash
ssh root@your.server
curl -O http://vestacp.com/pub/vst-install.sh
bash vst-install.sh
```

==uploading a website==
http://www.servermom.org/add-new-website-vesta-cp/1066/
