---
title: YouMagine
---

=====API documentation=====
https://api.youmagine.com/

=====undocumented API=====
Daid on Ultimaker forum: "You can also access a lot of the public information without an token. Example: https://www.youmagine.com/users/daid.json. Pretty much every page is accessible as json, but the "logged in" data requires an access token. Not sure if this is by design or by mistake.

===get info about 'document' with ID===
* https://www.youmagine.com/documents/20889.json
