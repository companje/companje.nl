---
title: e XCode
---

=====see feedback from build phases=====
Cmd+8  
filter by time: left bottom clock icon

=====warnings=====
To generate warnings in XCode when a non-void function lacks to return a value enable the return type warning:
```
-Wreturn-type
```

=====zie ook======
* [[osx]]
* [[ios]]

=====shortcut keys=====
`⇧ + ⌘ + O`  (letter 'O'): Open Quickly
