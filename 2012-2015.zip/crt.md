---
title: CRT
---
* http://www.repairfaq.org/sam/crtfaq.htm
* http://www.instructables.com/id/How-To-Make-A-CRT-TV-Into-an-Oscilloscope/?ALLSTEPS
* http://www.instructables.com/id/Fully-Functional-Television-Oscilloscope/
* http://bobparadiso.com/2015/04/13/crt-electron-beam-deflection-w-microcontroller/
* https://forums.adafruit.com/viewtopic.php?f=8&p=96076
* https://datasheets.maximintegrated.com/en/ds/MAX532.pdf
