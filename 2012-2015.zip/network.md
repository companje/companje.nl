---
title: Network
---

==get ip + mac address of all connected network devices==
```arp -an```
