---
title: TodaysArt
---
(  http://www.globe4d.com/wp-content/uploads/2007/08/todaysart.png)
TodaysArt strongly believes in fresh and vigorous creativity and in new forms of expression. The festival welcomes rising talents who boldly explore the possibilities of the new and controversial, offering them a place in the spotlights to openly express their talent talent in the field of Music, Visual Arts, Photography, Dance, Fashion, Multimedia, Theater, Film and Video.
\
*[[Globe4D]] has been exhibited at [[TodaysArt 2007]]
*Art festival in [[Den Haag]]
