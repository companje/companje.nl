---
title: Assembler
---
* https://www.onlinedisassembler.com/odaweb/
* JetBrains dotPeek (.NET decompiler)
