---
title: Telnet
---

===== pipe telnet output to file =====
```bash
telnet 192.168.1.1 | tee telnet.log
> cat *.svg
> exit
cat telnet.log
```
