---
title: Frankrijk 2002
---
In de zomer van 2002 was ik met Arno, Rogier en Joep op vakantie in La Palmier in Frankrijk.
