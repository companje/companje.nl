---
title: Rijksmuseum Amsterdam
---
Tijdens het laatste half jaar van mijn bachelor Interaction Design in 2004 ontwikkelde ik “De tijdslijn” voor het Rijksmuseum. Toen der tijd een presentatie van de Nederlandse Meesterwerken uit de Gouden Eeuw, maar zo gebouwd dat ie zo weer van de plank gehaald kon worden. En dat is nu gebeurd. En hoe!

‘De Tijdslijn’ is weer helemaal terug, en als nooit tevoren! Ontwerpbureau Fabrique heeft ‘m nieuw leven ingeblazen. Op basis van mijn oude code en gedachtengoed, maar wel met aantal sterke verbeteringen. Zo is de filter nu een stuk prominenter maar vooral intuitiever, staan de scrollbalkjes voor het reizen door de tijd en het kiezen het detailniveau op een betere plaats en valt er per kunstwerk een heleboel te lezen en te zien.

(http://www.companje.nl/wp-content/uploads/2006/11/rijksmuseum-tijdslijn-tijdlijn-canon.jpg)

Een visuele reis door de tijd, langs belangrijke personen, gebeurtenissen en thema’s: een combinatie van de canon en de presentatie in het nieuwe Rijksmuseum. Deze special van het Nederlandse verleden in internationale context zal met regelmaat uitgebreid worden. (www.rijksmuseum.nl)

(http://www.companje.nl/wp-content/uploads/2006/11/rijkscanon.jpg)

(tag>Museums)
