---
title: =====GDB (GNU Debugger) =====
---

```
gdb datamining
(gdb) run
(gdb) bt
```

==Debugger settings in CodeBlocks==
Je kunt catch debugger exceptions flag uitzetten want bij het debuggen zijn exceptions die netjes afgevangen worden meestal helemaal niet erg.
