---
title: HTTP
---

====Easy webserver: mongoose====
  brew install mongoose
if will serve the files in the folder where it's started from:
  cd Downloads
  mongoose
  Mongoose web server v.5.2 serving [/Users/rick/Downloads] on port 8080
