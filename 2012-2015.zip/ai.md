---
title: AI / Machine learning
type: other
---
* http://www.wekinator.org/

===== Google AI =====
* http://googleresearch.blogspot.co.uk/2015/11/tensorflow-googles-latest-machine_9.html
* http://www.popsci.com/google-ai
