---
title: Flex & Flash
---
Ik werk sinds november 2004 met Flash en sinds november 2005 met Flex.

===== Flash =====
*[[Tijdslijn]] voor het Rijksmuseum
*[[ScriptMachine]] voor het Museum voor Beeld en Geluid
*[[PiPiView]] webalbum viewer voor Picasa. In gebruik op ZOOM.nl

===== Flex =====
*[[Frame Digital Magazine]]
*[[Creatieve Kaart Leiden]]
*[[TravelTrace]]
*[[Bashi]]
