---
title: ADM 3A terminal
---
* [[http://juliepalooza.8m.com/sl/adm3a-2.htm|ADM-3A Lower Case Option "Clone"]]
* [[http://www.rogtronics.net/files/datasheets/uarts/AY-5-1013.pdf|AY-5-1UART chip]]
* [[http://bitsavers.informatik.uni-stuttgart.de/pdf/learSiegler/|Various manuals as PDF]]
