---
title: Het Lab
---
Het Lab is een populair wetenschappelijk programma waarin bizarre en idiote experimenten worden gedaan, theorieën worden getoetst en psychologische testen worden uitgevoerd. 
\
Ik was een van de nerds uit Het Lab in het najaar van [[2007]]
