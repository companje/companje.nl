---
title: MS-DOS
---
* http://www.dcee.net/Files/Utils/
* http://www.legroom.net/howto/msdos

=====bypass config.sys and autoexec.bat=====
Press F5 when MS-DOS is booting
