---
title: Unicode
---

see [[encoding]]
