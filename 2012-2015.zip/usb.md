---
title: USB
---

===== USBlyzer =====
* [[http://www.usblyzer.com/|USB Protocol Analyzer and USB Traffic Sniffer]]

===== USB audio chip ======
* http://nl.farnell.com/texas-instruments/pcm2706pjtg4/ic-dac-audio-usb-smd-tqfp32-32/dp/1390710
