---
title: =====Illustrator=====
---

==Shortcut keys==
|''F7''|Show/hide Layers|
|''Cmd+Y''|Outline View|
|'', . /''|wisselen tussen 3 soorten fills (solid, gradient, transparent)|
|''Shift+c''|convert anchor point tool (wisselen tussen rechte hoeken of curves)|
|''p''|pen tool|
|''=''|(+) add anchor points|
|''-''|remove anchor points|
|''Cmd+U''|smart guides on/off|
|''Cmd+[ or ]''|arrange forward / backward within layer|
|''x''|kiezen of fill of stroke geselecteerd moet zijn|
|''Shift+x''|stroke/fill kleur omdraaien van het geselecteerde object|
|''Shift+Cmd+a''|Deselect|
|''Cmd+F10''|show/hide stroke panel|
|''r''|rotate tool|
|''o''|reflect tool|
|''s''|scale tool|
|''shift+O''|open artboard settings|
|Cmd+Shift+B|handles aan/uit o.a. om Free Transform te kunnen doen|

==Tips==
 * Op de paper-size in te stellen kun je bij Document Properties -> Edit ArtBoards gebruiken. Klinkt als een omslachtige methode dus misschien is er een betere.
 * Als je iets geselecteerd hebt met de Direct Selection Tool (a) dan kun je met Cmd op het geheel een soort Free Transform doen.
