---
title: Universiteit Leiden
---
*In september [[2005]] begon ik aan de Master of Science studie [[Media Technology]] aan de [[Universiteit Leiden]].
