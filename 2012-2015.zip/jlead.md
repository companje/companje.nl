---
title: J-Lead LEDs (smd through hole)
---
* https://octopart.com/hlmp-6000-avago-32045
