---
title: Textile
---

====knityak====
https://www.kickstarter.com/projects/fbz/knityak-custom-mathematical-knit-scarves/description

====OpenTextile====
__Peter to FabLab Amersfoort__: Deze CCC lezing vinden jullie misschien wel interessant. Gaat over projecten die de textiel industrie willen moderniseren met moderne technieken en opensource software om de productie onder andere persoonlijker te maken en met minder handwerk. Dus veel gaat over digitale fabricage voor kleding. 
http://youtu.be/k0DNnyknWKM?list=PLOcrXzpA0W83uyr5LX-U47F3V5IfAZ-UP. 
Hun website: 
https://fashiontec.wordpress.com/

Projecten die bijv langskomen: 
* http://ayab-knitting.com/
* http://openknit.org/
* http://valentinaproject.bitbucket.org/
* http://embroidermodder.org/
* https://github.com/fashiontec/bodyapps-android
