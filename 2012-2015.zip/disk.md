---
title: Disks / Floppy Drives / Boot
---
* http://support.microsoft.com/kb/140060
* http://community.spiceworks.com/how_to/1175-how-to-install-ms-dos-6-22-after-installing-xp
* http://jope.fi/drives/
* http://www.thpc.info/how/editbootini.html
* http://www.allbootdisks.com/download/iso.html
* https://www.schoonepc.nl/nieuwsbrief/multiboot_systeem_opzetten.html
* https://www.schoonepc.nl/instal/multibt.html
* http://www.masterbooter.com/
* http://apps.tempel.org/iBored/  

* 160k raw to imd [[ https://winworldpc.com/winboards//viewtopic.php?f=36&t=6931|source]]: ```BIN2IMD <image.img> <image.imd> DM=5 N=40 SS=512 SM=1-8 /1```

* "Some image utilities will get confused and die on 8-sector or single sided formats - Especially if the disks were created by DOS 1.x and missing the media descriptor information. ImageDisk can handle those OK. " [[http://www.vintage-computer.com/vcforum/archive/index.php/t-36239.html|source]]
* http://dosmandrivel.blogspot.nl/
