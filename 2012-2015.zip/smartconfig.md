---
title: CC3000 SmartConfig
---

see [[cc3000]]
