---
title: Ideas
---
*Bestaat er een 3D spiegel? Of is een spiegel altijd 3D als in stereoscopisch? Dat laatste denk ik. Is het niet cool om standaard in een laptop twee ingebouwde camera's te hebben om het gewebcamde beeld realistischer te maken? Heb je wel een speciaal scherm of goggles nodig...
*[[USB Infuus]] om eten binnen te krijgen tijdens het emailen... (credits to [[friends:Nico van Dijk|Nico]])
*Is het een idee om wetenschappelijk te onderzoeken of het gevoel '[[Clipboard in your head]]' bij meer mensen dan mij alleen aanwezig is? En hoe het werkt? Het voelt als een soort 'binary flag'. Een soort bitje in je hoofd die op 1 staat als er nog iets op je clipboard zit in je computer... vreemd. edit: Pas had ik zelfs de ervaring dat mijn hoofd onbewust aan het bijhouden was of er nog data op iemand anders' clipboard zat.
* Bij het gebrek aan een paste functie voor images op internet zou je afbeeldingen in je OS moeten kunnen opslaan op je clipboard als BASE64 tekst en die vervolgens moeten kunnen plakken op het web. In deze Wiki bijvoorbeeld. Dat ie in ieder geval op die manier automatisch 'geupload' wordt bij het saven van je pagina.
* Klok die een sinus achterlaat per wijzer met een pennetje op een voorbijscrollende rol. [[http://www.cs.sbcc.net/%7Ephysics/flash/optics/phasors4.html|1]]. Misschien wel leuk om ook de klepel/pendulum te registreren. En ook de terugkerende cycli in het jaar.
* Gisteravond (17-11-2007) bedacht ik dat het ontzettend fijn kan zijn om een soort grafische editor a la aquabrowser/mindmapping te gebruiken om een wiki in te vullen. Ik kan me voorstellen dat wanneer je in bijvoorbeeld Flex een editor maakt die gebruik maakt van graven dat je dan een super gebruiksvriendelijke en snelle Wiki editor kunt maken.
* Het idee van Harmen van een soort hyperhypertext waarbij ieder (relevant) woord in een tekst linkt naar alle pagina's waarop dat woord voorkomt. Of als rollover menu of als een stapel semi transparante 'A4'tjes' die waarbij de woorden op elkaar gestapeld zijn. 
*armbandjes van vroeger fluoriserend die je zo om je arm kon slaan. Wellicht te combineren met epaper??? Teken je eigen print.
*Experiment waarbij ik alles wat ik in m'n huis heb staan te koop zet voor de emotionele waarde. Alles wat je hebt opnieuw inventariseren en op waarde inschatten.
*Idee: zoek machine die met je meedenkt. Je kunt wel 'refinen' maar als je bepaalde dingen hebt weggefiltert dan zou ie eigenlijk bij de volgende refine wel even weer moeten checken of 't nog steeds klopt.
*Eigenlijk wil ik een website die altijd in edit-mode staat en waarbij iedere pagina die nog niet bestaat meteen aangemaakt wordt en waar je kunt gaan typen in wikistijl met lookup functie voor links en een paste functie voor plaatjes.
*Idee: 100 woorden die mijn huidige leven typeren en dat ieder kwartaal doen en visualiseren.
*De hoeveelheid beweging in een reeks beeld om de snelheid van het filmpje te bepalen. Als er veel gebeurd gaat het filmpje trager. Als er weinig gebeurd versneld het filmpje. Uiteraard moet dit geleidelijk / smooth gaan. 
*De NS omroeper stem samplen en daarmee synthen met een [[http://www.youtube.com/watch?v=q9tmbrG7D-o|Auduino]]

====== Links to this page ======
(backlinks>.)
