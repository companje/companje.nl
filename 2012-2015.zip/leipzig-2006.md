---
title: Rick en Dora in Leipzig 2006
---
(youtube>large:TDYvnh5cm1g)
(tag>Travel)
