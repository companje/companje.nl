---
title: Serial communication
---

*zie ook [[ftdi]], [[usbserial]], [[ios]]
*[[http://www.hw-group.com/products/hercules/index_de.html]]
*max232 board from goodluckbuy: [[http://www.goodluckbuy.com/jy-r2t-v1-2-rs232-serial-port-converter-w-cable.html|JY-R2T V1.2 Rs232 Serial Port Converter w/ Cable]]
* https://www.olimex.com/Products/Components/Cables/USB-Serial-Cable/USB-Serial-Cable-F/ (PL2303): SERIAL output 3.3V voltage levels, GND=BLUE, RX(INPUT)=GREEN, TX(OUTPUT)=RED
* alternatives to FTDI: CH340G, CP2102, PL2303
* RS-232 current loop converter


=====Tools=====
* overview: http://www.rau-deaver.org/MacTerminals.html
* SerialTools [[https://itunes.apple.com/us/app/serialtools/id611021963?mt=8|for osx]]
* [[http://www.hhdsoftware.com/dispatch/fspm/download/serial-monitor|Device Monitoring Studio]] (Windows, werkt ook in Parallels op OSX) 2wk trial daarna +/-$50
