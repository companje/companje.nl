---
title: SPI
---
* https://nl.wikipedia.org/wiki/Serial_Peripheral_Interface
* [[http://www.multiwingspan.co.uk/arduino.php?page=nokia|Nokia 5110 display Arduino code]]
