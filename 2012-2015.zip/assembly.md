---
title: Assembly
---

===== Snake game in assembly code =====
GSnake is een in assembly geschreven grafische Snake variant die ik heb gemaakt in 1996 (deels gebaseerd op code van iemand anders maar ik weet niet meer van wie). Heel lang heb ik gedacht dat de originele sourcecode verloren was gegaan maar op 14-11-2007 ontdekte ik in een mapje met de naam ASMLAB een kopie van de source.

(:gsnake.jpg)

''SNAKE.COM v1.00  by Rick Companje 17/12/1996
Copyright (C) 1996  TMR Software Productions
The last update was on 06/01/97 at 22:37:07''

==== Sourcecode ====
%gist(57eb18b0850f9101fba8)%
