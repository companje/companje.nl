---
title: Notes
---
*[[https://help.ubuntu.com/community/SwitchingToUbuntu/FromWindows|Switching to Ubuntu from Windows]]
*http://www.kitchenbudapest.hu/hu/projects/landprint
*[[http://technology.newscientist.com/article/dn12798-multitouch-display-can-see-objects-too.html|LED's als sensor]]
