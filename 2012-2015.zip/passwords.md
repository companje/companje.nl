---
title: Passwords
---
* http://lastpass.com
* https://www.keepassx.org
