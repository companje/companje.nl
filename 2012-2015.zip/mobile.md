---
title: Mobile
---
* [[http://speckyboy.com/2012/05/16/creating-a-mobile-web-application-with-meta-tags/|Creating a Mobile Web Application with Meta Tags]]
* [[http://blogs.adobe.com/cantrell/archives/2011/11/building-an-offline-mobile-web-application.html|Building an Offline Mobile Web Application]]
* [[http://mobile.tutsplus.com/tutorials/iphone/iphone-web-app-meta-tags/|Configuring an iPhone Web App With Meta Tags (+jQuery)]]
* [[http://matt.might.net/articles/how-to-native-iphone-ipad-apps-in-javascript/|Create native-looking iPhone/iPad applications from HTML, CSS and JavaScript]]
* [[http://www.luscarpa.com/development/make-your-website-an-iphone-web-application/|Make your website an iPhone web application]]
* [[http://sixrevisions.com/web-development/html5-iphone-app/|How to Make an HTML5 iPhone App]]
* [[http://anders.zakrisson.se/projects/creating-html-5-web-app-ipad/|Creating a HTML 5 Web App for iPad – Part 1]]
