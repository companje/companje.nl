---
title: Backup
---

* see [osx](osx), [duplicates](duplicates)
* [Carbon Copy Cloner](http://bombich.com/) for osx
