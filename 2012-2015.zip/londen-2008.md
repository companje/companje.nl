---
title: Londen 2008
---
De eerste week van juni ben ik samen met Dora in Londen.
