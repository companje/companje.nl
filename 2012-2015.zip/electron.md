---
title: Electron
---

===== unpack asar files =====
https://github.com/atom/asar
