---
title: Forth
---

==intro==
* https://youtu.be/gFE6oK7jkq4

==META Workshop ForthTV 25+26 May 2007 by Tom Schouten==
* https://www.youtube.com/embed/cNdic7pe5UU
