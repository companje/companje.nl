---
title: Harddisk hacking
---

De lezing van OHM: http://bofh.nikhef.nl/events/OHM/video/d2-t1-13-20130801-2300-hard_disks_more_than_just_block_devices-sprite_tm.m4v.
              
En in meer detail: http://spritesmods.com/?art=hddhack
