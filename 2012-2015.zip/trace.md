---
title: ImageTracing
---
===== Potrace =====
* http://potrace.sourceforge.net
* http://potrace.sourceforge.net/faq.html

==== Autotrace ====
* [[http://autotrace.sourceforge.net/|Autotrace]] can do centerline trace
* http://www.roitsystems.com/cgi-bin/autotrace/tracer.pl
