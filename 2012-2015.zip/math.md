---
title: Math
---

=====matrix & quaternion FAQ=====
* http://www.j3d.org/matrix_faq/matrfaq_latest.html

=====e=====
* http://nl.wikipedia.org/wiki/E_(wiskunde)

=====greek symbols=====
* http://www.exelisvis.com/docs/html/images/greekLetters.png
