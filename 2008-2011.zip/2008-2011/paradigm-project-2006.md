---
title: Paradigm Project (2006)
---
ID: Paradigm Project (2006)
PDF: (afstuderen:Paradigm Project (2006).pdf|)

===== Summary =====
*Personal Archives Accessible in Digital Media (paradigm)
*preserving digital private papers
*Project outcomes
**A template for ensuring long-term access for institutional holdings of digital personal papers
**Best-practice guidelines in the form of a workbook
**local institutional capacity for digital preservation
**Practical test of digital repository softwares DSpace and Fedora and related tools
**Investigation and report on the potential of the Archives Hub
**Research resources for 20th century political history in the form of new archival collections

*Wat is [[DSPACE]]?
*Wat is [[Fedora]]?
*Wat is [[Archives Hub]]?
