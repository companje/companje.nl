---
title: Push Notification voor iPhone
---
Deze handleiding die ik heb samengesteld uit verschillende bronnen kan handig zijn wanneer je iets wilt doen met Push Notificatie op de iPhone.
\
\ (:blog:push-notificatie-voor-iphone.pdf|Push Notificatie voor iPhone)

(tag>iPhone Programming Tech PHP)


~~DISCUSSION~~
