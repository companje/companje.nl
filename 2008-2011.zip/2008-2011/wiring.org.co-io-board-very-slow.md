---
title: Wiring.org.co IO board very slow
---
If you encounter the problem of a very slow starting Wiring.org.co microcontroller, try to uninstall your (BlueSoleil) BlueTooth drivers.

(tag>Electronics)


~~DISCUSSION~~
