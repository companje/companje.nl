---
title: Kshitij 2008
---
(blog:kshitij-2008.png|Kshitij 2008)

Kshitij is the annual techno-management festival of IIT Kharagpur. We hold a series of technical and managerial events, guest lectures and workshops. Started in 2004, the 2007 edition was the largest of its kind in the whole of Asia, with 6000 odd student participation, around 300 participating colleges from all over the country and 25.3 lakh worth of prizes. Continuing the trend of previous years, Kshitij 2008 promises to be bigger than any of its predecessors. With over 30 lakh hits on this year's site and about 6000 registered users already, Kshitij'08 is showing signs of a prodigy. It will be held from the 31st January to 3rd February, 2008. Our official site is: www.ktj.in

'Kshitij' is not going to leave even a single event where there is an application of innovation. Here's yet another software designing event 'Javawise'. As the name suggests the participant will have to design software using java programming language on J2ME. It's an open source event. The maximum team size will be 4. The event will be composed of two rounds. The participating teams will have to submit the zipped folders of their codes before 16th of December.

Based on the online submissions the teams will be short listed for the final round, which will be held during 'Kshitij' (31st Jan to 3rd Feb) at IIT Kharagpur. Being open source, the source code will be uploaded at our website www.ktj.in . Another distinctive aspect of this event is that the judging parameters will also be decided by the teams. Detailed description of the event is at our website www.ktj.in . The hunt for innovative and smart brains is on, and the invitation is open to all. 

(tag>Globe4D Events Travel)
