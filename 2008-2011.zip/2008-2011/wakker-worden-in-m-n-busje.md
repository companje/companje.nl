---
title: 
---
Ik heb al bijna 3 maanden niet meer geblogd... Er is erg veel gebeurd in de tussentijd. Veel waar ik over had kunnen schrijven maar wat ik niet heb gedaan. Daarnaast ben ook gewoon veel te druk met het slapen in m'n busje en het ontdekken waar ik de volgende dag weer eens wakker wordt. Laat staan dat daar internet aan te pas komt.

Onderstaande foto is gemaakt vanuit mijn bus de ochtend na het Dennestok '69 feest op de dag van de drinkende dieren in Baarn. Het feest waar tijdens een badkamerconcert van de broertjes Borger een nieuw tijdperk lijkt te zijn aangebroken...

(blog:wakker-worden-in-mn-busje-1024.jpg?550|)

(blog:dennestok.jpg?550|)

(tag>)

~~DISCUSSION~~
