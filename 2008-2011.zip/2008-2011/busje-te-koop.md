---
title: Busje te koop!
---

<html><font color=red size=+5>VERKOCHT</font><br/></html>
Eigenlijk wil ik 't helemaal niet want hij is veel te leuk. Maar helaas, het moet... ik heb er twee (van de 200 die er nog in Nederland rondrijden) en dat is een beetje overdreven lijkt me... Bij deze bied ik dus mijn witte Renault Estafette camper-busje uit 1976 te koop aan!
\
**De koper moet voldoen aan de volgende eigenschappen:**  
\
*hij/zij zal goed voor het busje zorgen.
*hij/zij is avontuurlijk ingesteld.
*hij/zij zorgt dat het busje een mooie lik witte verf krijgt want het busje voelt zich nu een beetje kaal.
*hij/zij geeft mij af en toe updates hoe het busje bevalt en welke avonturen er mee beleefd worden.
\
**Het busje belooft:**  
*technisch zo goed mogelijk te functioneren.
*te zorgen voor veel avontuur en twee-pits maaltijden tijdens mooie zonsondergangen op mooie plekjes. 
\
**De verkoper belooft:**
*niet rijk te willen worden van de verkoop.
*veel te vertellen over de avonturen die er mee beleefd zijn.
*advies en documentatie te geven bij de verkoop en tijdens het gebruik.
\
//Wit Renault Estafette Camper Busje / Kampeerauto 1976, foto gemaakt op het 'Wilde Stukje' op Rijnfront nabij Leiden//
(blog:wit-renault-estafette-camper-busje-1976.jpg?550|Wit Renault Estafette Camper Busje / Kampeerauto 1976, foto gemaakt op het 'Wilde Stukje' op Rijnfront nabij Leiden)

//Wit Renault Estafette Camper Busje / Kampeerauto 1976, foto gemaakt tussen Baarn en Hilversum//
(blog:wit-renault-estafette-camper-busje-1976-2.jpg?550|Wit Renault Estafette Camper Busje / Kampeerauto 1976, foto gemaakt tussen Baarn en Hilversum)

//Wit Renault Estafette Camper Busje / Kampeerauto 1976, foto gemaakt door Hilde bij Shell Binckhorst Den Haag//
(blog:2008:12:wit-renault-estafette-camper-busje-1976-3.jpg?550|Wit Renault Estafette Camper Busje / Kampeerauto 1976, foto gemaakt door Hilde bij Shell Binckhorst Den Haag)

*PS. Qua prijs zullen we ergens moeten uitkomen tussen 1850 en 1500 euro.
*PS2. De APK keuring is nog geldig tot  **27 augustus 2010** !! (2 jaar geldig want de auto is ouder dan 30 jaar)
*PS3. Het busje is motorisch goed, **remsysteem en ontsteking** zijn onlangs **gereviseerd**, de lak heeft wel de nodige aandacht nodig.
*PS4. Het busje bevat een **complete campeer-uitrusting**: tweepersoons bed in te klappen tot driezitsbank, 3 stoelen uitgerust met gordel, binnen- en buitenverlichting, gasfornuis, servies, extra tent, gaskachel, stuurslot en evt. koelkast.
*PS5. Mocht je nou echt het blauwe busje willen i.p.v. de witte dan valt daar over te praten maar reken op een aanzienlijk hogere prijs.

Reacties graag per email naar rick apenstaartje companje punt nl, of bel 06-2851 6908 voor meer informatie of om een afspraak te maken voor bezichtiging.

//Blauw Renault Estafette Camper Busje / Kampeerauto 1980, foto gemaakt bij studentenhuis Dennestok te Baarn//
(blog:2008:12:blauwe-renault-estafette-camper-busje-1980-3.jpg?550|Blauw Renault Estafette Camper Busje / Kampeerauto 1980, foto gemaakt bij studentenhuis Dennestok te Baarn)

(blog:2008:12:blauwe-renault-estafette-camper-busje-1980.jpg?550|Blauw Renault Estafette Camper Busje / Kampeerauto 1980, foto gemaakt bij studentenhuis Dennestok te Baarn)

(blog:2008:12:blauwe-renault-estafette-camper-busje-1980-2.jpg?550|Blauw Renault Estafette Camper Busje / Kampeerauto 1980, foto gemaakt bij studentenhuis Dennestok te Baarn)

(tag>Travel)

~~DISCUSSION~~
