---
title: OLED displays via USB
---
Dit wordt leuk. De OLED displays zijn enorm betaalbaar aan het worden. Het onderstaande 1,5 inch schermpje kost maar een kleine 75 euro.
(blog:uoled128-groot.jpg?550|OLED displays via USB)
[[http://www.antratek.nl/4dsystems.html]]

(tag>Tech Electronics)


~~DISCUSSION~~
