---
title: Globe4D naar India
---
Goed nieuws! We demonstreren het nieuwe [[:Globe4D]] productiemodel op een groot technologie festival in India [[:Kshitij 2008]] van 31 januari t/m 3 februari 2008!

(blog:kshitij-2008.png|Globe4D at Khsitij 2008 festival in India)

<blockquote>
Kshitij is a techno-management fest conducted by IIT-Kharagpur with sponsors including Barclays Capital, Intel, Ceat, Google, SBI and Adobe.

Kshitij hosts a galaxy of events aimed at boosting the technological and managerial skills inherent in todayÂ´s youth and providing them with an opportunity to showcase their innovative ideas and thoughts. The events in Kshitij cover almost every thinkable domain in the field of technology and management.These form the heart and soul of the festival and seek to provide a common platform for the best brains to interact and nurture their seedling ideas transforming them into giant trees of innovation and progress. The events serve to inculcate the spirit of innovative thinking amongst the finest technical and managerial brains in the country. http://letmeknow.wordpress.com
</blockquote>

(tag>Events Conferences Globe4D)
