---
title: Terug naar Utrecht
---
Ik woon weer in Utrecht. Na een half jaar per ongeluk in Katwijk gewoond te hebben zit ik nu toch gelukkig weer wat centraler. Mijn nieuwe huisje zit vlak bij het Wilhelminapark aan de Nicolaasweg 54. Misschien geef ik binnenkort nog wel een huisverwarmingsfeestje met uitloop naar het Wilhelminapark. Nader bericht volgt.
\
(:blog:nicolaasweg-54-utrecht.jpg?500|)

(tag>Photos)


~~DISCUSSION~~
