---
title: Het misterie achter de kwijtgeraakte sokken in de wachmachine
---
De tweedejaars studenten die ik begeleid van de opleiding ‘Design for Virtual Theater and Games’ van de Hogeschool voor de Kunsten Utrecht onderzoeken tijdens het vak Physical Computing het misterie achter de kwijtgeraakte sokken in de wasmachine en komen met een interessante oplossing: De SokkenAtor.

(http://sokkenator.nl/wp-content/uploads/2009/11/sokinator.jpg?550)

Lees meer op http://sokkenator.nl/

(tag>Art Tech Fun)


~~DISCUSSION~~
