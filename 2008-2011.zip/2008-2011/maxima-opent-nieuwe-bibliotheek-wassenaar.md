---
title: Maxima opent nieuwe Bibliotheek van Wassenaar
---
Op 29 juni 2009 werd de nieuwe bibliotheek van Wassenaar geopend met in de collectie ondermeer een exemplaar van Globe4D. Wassenaar laat daarmee als eerste bibliotheek in Nederland interactieve kaarten over het verplaatsen van de mensheid over de aarde zien op een fysieke wereldbol: animaties over de verspreiding van de mensheid over de afgelopen 200.000 jaar, maar ook hedendaagse vliegtuigroutes en een interactief helikopter-spel voor het leren van topografie.
\
Prinses Máxima voltrok de officiële opening en is op de onderstaande te zien met Globe4D.
\
(:blog:2009:05:grotefoto-dlxfblbo.jpg?500|Prinses  Máxima opent de nieuwe bibliotheek van Wassenaar en bekijkt Globe4D)

<blockquote>Hare Koninklijke Hoogheid Prinses Máxima der Nederlanden opent maandagmiddag 29 juni de nieuwe openbare bibliotheek in Wassenaar.
De nieuwe bibliotheek in Wassenaar, onderdeel van de Stichting Openbare Bibliotheek Voorschoten - Wassenaar, komt tegemoet aan de wensen van deze tijd. Zo wordt veel informatie digitaal aangeboden. Er zijn bijvoorbeeld 500 buitenlandse kranten dagelijks online beschikbaar.
Tevens is veel aandacht uitgegaan naar de jeugdafdeling die onderverdeeld is naar leeftijd. Op deze afdeling staat een aquarium waar kinderen via een computer kunnen leren over de zee, biotopen en landen waar de vissen vandaan komen. **De oudere jeugd kan via een vierdimensionale globe op interactieve wijze de wereld ontdekken.**
Daarnaast beschikt de bibliotheek over een filmhuis. Naast een wekelijkse programmering is de filmzaal ook beschikbaar voor lezingen en culturele activiteiten.</blockquote>


(tag>Globe4D)


~~DISCUSSION~~
