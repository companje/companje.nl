---
title: Renault Estafette
---
Op [[23 mei 2008]] kocht ik mijn Renault Estafette busje van een dame uit Oss. Diezelfde dag nog bracht ik 'm in Utrecht naar de Garage naast [[dB's]] voor de keuring. Dinsdag's haalde ik 'm weer op. Het lijkt er op dat de bus in aardig goede staat is. Er moet nog wel wat gebeuren aan de remmen, er is een remslangetje in bestelling.
\
(blog:renault-estafette.jpg?550|)
\
Ik heb me op [[30 mei 2008]] vanuit mijn bus voor het huis van Dora draadloos aangemeld bij de vereniging 'Vrienden van de Estafette' op http://www.renault-estafette.nl.
