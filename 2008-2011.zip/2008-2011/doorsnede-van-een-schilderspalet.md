---
title: Doorsnede van een schilderspalet
---
Ik wilde een doorsnede maken van het schilderspalet van mijn vader omdat ik benieuwd was naar de innerlijke structuur van de aangebrachte verf op een palet.
\
 [[http://www.companje.nl/projects/doorsnede-van-een-schilderspalet/fabmoment.pdf|(:blog:palet-1-200.jpg?245)]] [[http://www.companje.nl/projects/doorsnede-van-een-schilderspalet/fabmoment.pdf|(:blog:palet-2-200.jpg?245|)]]

 [[http://www.companje.nl/projects/doorsnede-van-een-schilderspalet/fabmoment.pdf|(:blog:2009:12:palet-frees-500.jpg|)]]

Lees verder als [[http://www.companje.nl/projects/doorsnede-van-een-schilderspalet/fabmoment.pdf|PDF]].  

Het palet is rechthoekig en 100x50cm groot. In de loop der tijd is er een laag verf van ruim 3cm op onststaan vooral in het midden. Ik heb gekozen om met de portaalfrees (Seron 1325) van Protospace een laag van 1cm vanaf het hoogste punt van het palet af te frezen. In Corel Draw heb ik een lijntekening gemaakt in een soort blokgolf achtige vorm zodat de machine in één lange penbeweging de verf van het palet kan affrezen.

De gebruikte frees heeft een platte kop en is 6mm dik. Er was ook een veel grotere frees van ongeveer 1,5cm maar ik achte de kans te groot dat er stukken verf zouden afbreken. In eerste instantie wou ik de frees in 4 lagen van 2.5mm laten frezen maar al snel bleek dat de acrylverf zacht genoeg was om de frees er in één keer door te kunnen laten gaan. Er kwamen ontzettend veel groffe vezelfs vanaf en ik moest dan ook met de stofzuigerslang vlak bij de freeskop zitten om het object en de ruimte schoon te houden.

<html><object width="425" height="344"><param name="movie" value="http://www.youtube.com/v/oPEJDoHsDZM&hl=nl_NL&fs=1&"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/oPEJDoHsDZM&hl=nl_NL&fs=1&" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="425" height="344"></embed></object></html>

Ik ben tevreden over het resultaat. Ik had een dergelijke structuur (marmer/oester-achtig) wel verwacht maar dat wit de overheersende kleur zou zijn aan de binnenkant daar had ik niet op gerekend. Ik weet nog niet precies hoe dit komt. Een mogelijk vervolg op dit experiment zou zijn om een nieuw pallet per millimeter af te frezen en dat proces (wat dagen zal duren) te filmen en na afloop de snelheid en periodieken binnen de film variabel te maken. Foto's en filmpjes van het proces tot nu toe zijn te vinden op www.companje.nl.

(tag>Art Projects)


~~DISCUSSION~~
