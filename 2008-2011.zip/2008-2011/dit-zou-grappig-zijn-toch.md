---
title: Dit zou best grappig zijn toch?
---
Ik vond zojuist dat ik grappigs bedacht had:

<code>
login as: admin
password: ******
 
Eigenlijk heeft u niet het goede wachtwoord ingevoerd... 
maar vooruit dan maar, we zien het dit keer door de vingers.

admin@local# ~
#cd /
#rm -rf
</code>

of

<code>
login as: admin
password: ********
Wrong password
password: ****
Wrong password
password: *********
Wrong password
password: *****
Wrong password
password: *******
Wrong password
password: ********
Wrong password... but ok...
this time you'll come away with it...
you were trying so hard...

admin@local$ 
admin@local# ~
#sudo rm -rf
</code>
(tag>Fun Nerd)


~~DISCUSSION~~
