---
title: Globe4D - ICT Delta 2010
---
<blockquote>[[http://www.ictdelta2010.nl/|ICTDelta 2010]] wordt het North Sea Jazz van ICT-onderzoek en -innovatie in Nederland: een bruisend festival met een mix van activiteiten op talloze terreinen! 
\
De expositie en het interactieve congres zijn gegroepeerd rond 9 thema’s, op allerlei gebieden. Deelnemers kunnen ter plekke hun eigen programma samenstellen. Van games naar databases, van 3-D naar medische toepassingen, van een kijkje in de onderzoekskeuken naar de gebruiksaspecten.
\
ICTDelta is voor iedereen die betrokken is bij ICT-onderzoek en –innovatie: bedrijven (ook buiten de ICT!), overheid, universiteiten, hogescholen en onderzoeksinstituten, maatschappelijke organisaties.  </blockquote>

<html><embed 
src='http://www.itzit.tv/iTZiTplayer.swf'
width='550'
height='330' align="top"
type='application/x-shockwave-flash'
id='single2'
name='single2'
bgcolor='undefined'
allowscriptaccess='always'
allowfullscreen='true'
wmode='transparent'
flashvars='file=http://www.itzit.tv/ictdelta2010/technologie/globe4d.flv&image=http://www.itzit.tv/ictdelta2010/technologie/globe4d.jpg&abouttext=iTZiT multimedia&aboutlink=http://www.itzit.com&plugins=tweetit-1&dock=true&link=http://www.itzit.tv/ictdelta2010/technologie/globe4d.html'/></html>

Globe4D is een interactieve wereldbol die een compleet nieuwe dimensie geeft aan vakken als geschiedenis en aardrijkskunde. Op de wereldbol in het midden van de tafel kunnen interactieve kaarten worden geprojecteerd, die meedraaien als je de wereldbol vastpakt. Niet alleen projecties van de aarde, maar ook van tal van andere planeten. De kaarten worden mede ontwikkeld door wetenschappers en onderzoekers. De Globe4D startte als onderzoeksproject van de Universiteit Leiden, en reist inmiddels de wereld rond naar conferenties en musea. Deze 4D wereldbol staat in natuurhistorische musea in Maastricht, Portugal en Seoel.

<html><embed 
src='http://www.itzit.tv/iTZiTplayer.swf'
width='550'
height='330' align="top"
type='application/x-shockwave-flash'
id='single2'
name='single2'
bgcolor='undefined'
allowscriptaccess='always'
allowfullscreen='true'
wmode='transparent'
flashvars='file=http://www.itzit.tv/ictdelta/ictdelta2009.flv&image=http://www.ictdelta2010.nl/ictdelta/images/001.png&abouttext=iTZiT multimedia&aboutlink=http://www.itzit.com&plugins=tweetit-1&dock=true&link=http://www.itzit.tv/ictdelta2010/technologie/globe4d.html'/></html>

(tag>Globe4D Events)


~~DISCUSSION~~
