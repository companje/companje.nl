---
title: Com Port with JScript
---
It's quite easy to write to a COM port through JScript. You don't need any ActiveX components if you just 'echo' to a port.

See [[tech:Write to COM port with JScript]]

(tag>)

~~DISCUSSION~~
