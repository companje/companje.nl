---
title: 10 oktober 2008
---
Overleg met Maarten bij mij in Utrecht

TODO
* Lezen over:
** MDS, multi-dimensional scaling. Verschil weten tussen linear/non-linear
** MDS in relatie met bollen
** Periodieken, cycli

*Met mijn idee over Globe4D als wetenschappelijke tool naar wetenschappers uit verschillende gebieden. Bijv. geologie, biologie, sterrenkunde, ...
*Mijn onderzoek hoeft niet uiniek te zijn. Het argument 'dat kun je toch ook gewoon op een plat beeldscherm' moet me niet tegenhouden. De globe voegt namelijk een tactiele ervaring toe. De combininatie projecteren op een bolvormig oppervlak en de directe tastbare interactie.
* Het gaat er binnen een wetenschappelijk onderzoek om kennis toe te voegen. 

*3D karakter van de bol,  er in kunnen kijken. Het leek Maarten een goed idee om als vooronderzoekje of als mogelijke eindrichting het effect van in de bol te kunnen kijken te onderzoeken.
**massa experiment dmv gelaagdheid. Diepere lagen bewegen op een andere snelheid dan de buitenste. Zoals bijv. het toevoegen van een wolken laag.
**Stereoscopy al was Maarten hier niet heel enthousiast over, ik denk dat het stereoscopisch projecteren op een bol nog niet eerder gedaan is en dat er interessante dingen uit zouden kunnen voorkomen. Normaal wordt er nl. geprojecteerd op een platscherm met stereoscopy, als je dat dat doet op een bol en je wilt dat het ook nog van alle kanten klopt dan moet je 
