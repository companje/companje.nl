---
title: 
---
Een mooi en heel beroemd artikel over wat we nu nano technologie noemen. Verschenen in 1960 door Richard Feynman. Zowel inhoudelijk als qua opbouw een leerzaam artikel.

ID: Feynman (1960)
PDF: (afstuderen:Feynman (1960) - There's Plenty of Room at the Bottom.pdf|)

===About Richard Feynman
Richard Phillips Feynman (New York, 11 mei 1918  Los Angeles, 15 februari 1988) was een Amerikaans natuurkundige. Richard Feynman was zeer invloedrijk op met name het gebied van de kwantumelektrodynamica (QED). In 1965 won hij de Nobelprijs voor Natuurkunde. Hij stond ook bekend als brandkastkraker, nachtclubgast, tekenaar, bongospeler en kenner van de Mayacultuur. Daarnaast schitterde hij kort voor zijn dood tijdens de openbare hoorzittingen na het ongeluk met de Space Shuttle Challenger. Niet in de laatste plaats was hij beroemd als didacticus. Door de meeste van zijn vakgenoten wordt hij zodanig vereerd, dat er veel uitspraken aan hem worden toegeschreven die waarschijnlijk niet van hem waren. (Wikipedia)

===There's Plenty of Room at the Bottom
*...Kamerlingh Onnes, who discovered a field like low temperature, which seems to be bottomless and in which one can go down and down. Such a man is then a and has some temporary monopoly in a scientific adventure. 
*Percy Bridgman, in designing a way to obtain higher pressures, opened up another new field and was able to move into it and to lead us all along. 
*What I want to talk about is the problem of manipulating and controlling things on a small scale.
*Why cannot we write the entire 24 volumes of the Encyclopedia Brittanica on the head of a pin?
*Let's see what would be involved.
*How do we write small? The next question is: How do we write
*We can reverse the lenses of the electron microscope in order to demagnify as well as magnify. A source of ions, sent through the microscope lenses in reverse, could be focused to a very small spot. We could write with that spot like we write in a TV cathode ray oscilloscope,
*We take light and, through an optical microscope running backwards, we focus it onto a very small photoelectric screen.
*That's the Encyclopaedia Brittanica on the head of a pin, but let's consider all the books in the world.
*instead of there being just the 24 volumes of the Encyclopaedia, there are 24 million volumes. The million pinheads can be put in a square of a thousand pins on a side,

..... 'moet' ik nog mee verder. Ik heb zoveel gemarkeerd in het document dat ik 'm net zo goed in z'n geheel hier kan copy-pasten. En het is niet heel relevant binnen m'n afstudeeronderzoek denk ik.
