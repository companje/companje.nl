---
title: E-Paint, a future vision movie about Paintable Displays
---
(youtube>large:ky2AvQYHUXo)
(tag>Projects)
