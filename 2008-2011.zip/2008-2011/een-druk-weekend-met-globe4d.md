---
title: Een druk weekend met Globe4D
---
Het komend weekend staat het ene Globe4D model die op dit moment nog op een basisschool in Ermelo gebruikt wordt op het [[:HappyChaos 2008]] (Genesis 2.0) evenement in [[:Pakhuis de Zwijger]] Amsterdam en daarna op [[:NWO]]'s [[:Bessensap 2008]] in [[:NEMO]].

Dit is een korte samenvatting van het plan voor komend weekend:

**Vrijdag:**  
8:00: [[:Hanco]] haalt het huurbusje en rijdt vanaf een afgesproken plek (Den Haag CS?) met [[:Nico]] en [[:Danica]] naar Ermelo.
8:00: Rick koopt zijn eigen nieuwe busje in Oss, rijdt er mee naar Utrecht en parkeert 'm alvast bij de garage, waar ie dinsdag moet zijn voor de keuring.
10:30: Overleg en afbreken [[:Globe4D]] in Ermelo (zonder Rick)
Daarna: Nico eventueel met trein terug vanaf Ermelo of vanaf Amersfoort.
Daarna: (bijv. 17 of 18u): Ontmoeten Danica, Hanco en Rick elkaar bij de [[:Spullenmannen]].
Rick heeft de sleutel en neemt die mee en weet ook de spullen te liggen. Rick neemt ook nog een hoop verlengsnoeren mee en gereedschap, sjorbanden en lijmklemmen en een balkje of stang (stang ligt nog bij de Spullenmannen).
Daarna: Inladen spullen en dan rijden Hanco en Danica met de bus naar het westen. Of Rick neemt de bus mee of Danica. Wat jullie het liefste willen. Ik begreep dat Danica het misschien wel een beetje moeilijk vind om voor de bus in Leiden een plaatsje te vinden. Ik neem 'm zonder probleem mee naar Utrecht en zet jullie daar af op het station.

**Zaterdag:**  
13.00: Aankomst Rick in Amsterdam bij Pakhuis de Zwijger.
Ook rond die tijd aankomst Danica. Maar mag ook iets later.
15:00 Als het opbouwen vlekkeloos gaat, gaat Rick er even een uurtje tussen uit voor een vergadering in de buurt. Valt het tegen dan blijft Rick opbouwen.
17:00 Hopelijk hebben we op dit moment de globe helemaal aan het draaien en zijn we al zelfs klaar met het inwerken van de vrijwilliger(s). Zo niet dan blijven we nog wat langer.
18:00 Rick uiterlijk weer weg. Moet naar [[:Geldrop]] toe voor feest van Dora's familie.
18:00 Danica ook weer weg
Overdragen van de autosleutel vind hier plaats. Is belangrijk dat Nico die krijgt voor het inladen 's avonds en ook voor de volgende dag.
18:00 of 19:00 Nico's aankomst. Afhankelijk van of we elkaar nog moeten zien.
19:30 Start van het het HappyChaos festival. Er moet vanaf dit moment continu een vrijwilliger bij de globe staan.
19:30 Aankomst Hanco.
Hanco en Nico maken kennis met de vrijwilliger(s) en checken even of ze de blijde boodschap goed kunnen overbrengen :-)  
Avond: Hanco en Nico gaan vooral genieten van de lezingen en komen af en toe even een kijkje nemen bij de vrijwilliger.
23:00 Globe afbreken en inladen in de bus. Hopelijk kan de bus gratis bij De Zwijger blijven staan 's nachts en de volgende dag.
23:15 Hanco en Nico gaan heerlijk genieten van warme DJ muziek en gaan pas naar huis als zij daar zin in hebben.

**Zondag:**  
12:45 Danica en Nico treffen elkaar op Station Leiden zodat Nico de oranje beamer krijgt.
13:15 Nico en Rick treffen elkaar op Amsterdam Centraal.
13:30 Nico en Rick halen de bus op bij pakhuis de zwijger en rijden naar NEMO.
14:00 Nico en Rick zetten de auto aan de zijkant van NEMO en gaan naar binnen en checken de zalen en zoeken een mooi plekje. We hebben geen mobiele nummers van de redactie dus we moeten het doen met de mensen die er op dat moment bij NEMO ook aan het opbouwen zijn. Rick belt nog even met Kim Wijngaard deze week.
14:15 de globe lossen bij NEMO en proberen daar zolang mogelijk de auto gratis te laten staan (laden lossen knipperlichten misschien).
18:00 Nico en Rick hopen nu helemaal klaar te zijn met opbouwen. Liefst eerder al en gaan naar huis. Rick zoekt een gratis plek voor de bus in Amsterdam en gaat met de trein naar huis.

**Maandag:**  
8:00 of 8:30 aankomst Rick bij NEMO. Met de trein (of met de bus als we een gratis parkeerplek hebben gevonden)
9:30 aankomst van de rest die er bij kan en wil zijn. Iedereen neemt zoveel mogelijk promotiemateriaal mee.
hele dag: praten met wetenschappers en journalisten, ansichtkaarten uitdelen maar ook handouts en folders (hebben we er er nog genoeg en zijn ze up to date?)
na afloop: (of eerder als we geen zin meer hebben): Rick: De bus halen, waar ie ook staat. Afbreken en inladen met z'n allen. Rick gaat met de bus naar [[:Amersfoort]], gaat uitladen en rijdt dan naar Utrecht om te gaan slapen.

**Dinsdag:**  
5:45: Rick staat op en vertrekt na een sterke bak koffie gedronken te hebben met de bus naar Den Haag. Levert 'm in en rijdt met het OV door naar [[:Noordwijk]] voor z'n eerste echte dag intern bij [[:ESA]].

(tag>Globe4D)


~~DISCUSSION~~
