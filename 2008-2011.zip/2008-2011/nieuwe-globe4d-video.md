---
title: Nieuwe Globe4D video
---
Je hoort me er niet zo heel vaak meer over misschien maar ik ben er toch nog wel elke dag mee bezig: Globe4D, en nu zelfs ook voor m'n afstuderen. Jullie zijn nog niet van me af.

<html><object width="425" height="344"><param name="movie" value="http://www.youtube.com/v/hN_oLwe75C0&hl=nl&fs=1"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/hN_oLwe75C0&hl=nl&fs=1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="425" height="344"></embed></object></html>

(tag>Globe4D Tech)


~~DISCUSSION~~
