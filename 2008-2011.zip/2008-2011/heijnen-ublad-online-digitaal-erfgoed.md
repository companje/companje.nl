---
title: Ublad Online - Digitaal Erfgoed
---
ID: Heijnen
PDF: (afstuderen:Heijnen - Ublad Online - Digitaal Erfgoed.pdf|)

===== Summary =====
*'digital born material' en 'gedigitaliseerd erfgoed'
*http://www.nationaalarchief.nl
**bijna duizend jaar geschiedenis van Nederland opgeslagen in 93 kilometer
**grootste openbare archiefinstelling in Nederland, kosteloos toegankelijk.
**particulieren, zoals het archief Johan de Witt
*http://www.geheugenvannederland.nl
**Het Geheugen van Nederland is een digitale verzameling van in totaal bijna 350.000 illustraties, foto's, teksten, films en audiofragmenten, afkomstig van tal van Nederlandse culturele instellingen en bijeengebracht door de Koninklijke Bibliotheek in Den Haag.
*http://www.anderetijden.nl
**tv-programma over bijna-ergeten gebeurtenissen, doorgaans uit een nog betrekkelijk recent verleden.
*http://www.keurderwetenschap.nl
**Ruim 200 wetenschappers stellen, voor zover mogelijk, hun intellectuele pennevruchten full text beschikbaar. De etalage van de Nederlandse wetenschap dus Met een zoekmogelijkheid per instelling, zodat Ineke Braakman, Willem Hendrik Gispen, Gerard van Koten, Frits van Oostrom, Herman Philipse of Gerard 't Hooft - en nog enkele tientallen meer - in één oogopslag zichtbaar komen, inclusief hun eventuele persoonlijke websites. Je kunt de wetenschappers ook alfabetisch of per vakgebied opspeuren.
*http://www.lexisnexis.nl
*http://dap.library.uu.nl
