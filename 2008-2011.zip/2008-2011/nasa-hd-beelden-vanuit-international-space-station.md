---
title: NASA video vanuit International Space Station
---
(youtube>large:JgBgmw-2U8c)

(tag>Tech)

~~DISCUSSION~~
