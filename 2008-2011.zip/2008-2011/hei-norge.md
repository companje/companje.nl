---
title: Hei Norge!
---
Morgen ga ik naar Noorwegen, Tromsø vlak bij de noordpool ! 4 dagen lang wetenschappers inspireren, lezingen geven en  samen exposeren met de [[http://www.spullenmannen.nl|Spullenmannen]]. Mijn onderdeel van de lezing is voornamelijk gericht op het inzetten van installaties (zoals Globe4D) ter ondersteuning van  wetenschappelijk onderzoek. Speciaal daarvoor heb ik een paar weken geleden de eerste mini-globe gemaakt, een mini-versie van [[http://www.globe4d.com|Globe4D]] speciaal voor onderweg.
\  
Ha det bra!
\  
PS.  Op [[http://www2.uit.no/www/startsida/tavla/arrangementsdetaljer?p_document_id=116976|deze website]]  staat het programma (in het Noors)
\  
(:blog:noorwegen-tromso.jpg|)

Hei alle sammen.

I morgen, onsdag 15.04.2009 kl. 14:00 til 16.00
vil det bli holdt en svært spesiell forelesning/forestilling på MH-bygget
ved Universitetet i Tromsø, Store aud.på plan 6

Gruppen De Spullenmannen fra Nederland viser eksperimentelt teater:
Vitenskap og kunst blir forenet i animasjoner, installasjoner, film og
teater. Møt opp og bli inspirert til formidling av forskning innen alle
fagområder!

Les mer om denne unike forestillingen på Universitetet sine [[http://www2.uit.no/www/startsida/tavla/arrangementsdetaljer?p_document_id=
116976| nettsider]]


(tag>Spullenmannen Globe4D Events Travel)


~~DISCUSSION~~
