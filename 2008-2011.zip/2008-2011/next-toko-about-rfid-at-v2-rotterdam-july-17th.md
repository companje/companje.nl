---
title: Next TOKO about RFID at V2 Rotterdam - July 17th
---
(  blog:2008:06:rfid.gif|RFID, Radio-frequency Identifier)TOKO workshops are about technical topics in the field of art, design and technology. Get inspiration or technical help from all the participants for your own creative projects. Each workshop speakers are being invited to share their knowledge and experiences. This 5th TOKO will be about RFID, radio-frequency identification. 
\
Confirmed speakers for this session are: [[http://www.tovernoot.nl|Iris Douma]] and [[http://nr37.nl|Leo van der Veen]]. 
\
More speakers will be announced at [[http://dewar.nl/toko|dewar.nl/toko]]. 
The workshop is free and open for everyone.
\
Please send an email to toko@dewar.nl to register for free and get more information.
\
location: [[http://www.v2.nl|V2]], Witte de Withstraat 63, Rotterdam
date/time: July 17th @ 14:00 till 20:00

(tag>Events Art Tech MediaTech)

~~DISCUSSION~~
