---
title: Alles beweegt - Jean Tinguely
---
Gisteren in de Kunsthal in Rotterdam naar de expositie Alles beweegt! van de kunstenaar Jean Tinguely geweest.                             Erg gaaf! Wees snel als je nog wilt gaan. Het duurt nog t/m 27 januari!

(blog:jean-tinguely.png|Alles beweegt - Jean Tinguely)

<blockquote>
10 oktober 2007 t/m 27 januari 2008

Voor het eerst sinds 1973 kan het Nederlandse publiek uitgebreid kennismaken met de fascinerende en dynamische kunstwerken van één van de iconen van de moderne kunst, Jean Tinguely (1925-1991). Tinguely is wereldberoemd om zijn bewegende sculpturen, nutteloze machines van roestig ijzer en afvalmateriaal. Jean Tinguely, Alles beweegt! geeft een groot overzicht van Tinguely’s kleurrijke oeuvre: van affiches en brieven tot zijn samenwerking met diverse kunstenaars, van zijn meest vroege tot zijn laatste werk. Middelpunt van de tentoonstelling is de imposante Luminator.</blockquote>

(tag>Art Museums)

~~DISCUSSION~~
