---
title: Veel Globe4D nieuws!
---

==== Eureka! ====
( http://www.globe4d.com/wp-content/uploads/2008/03/eureka%21.png?150|Globe4D in Eureka!)Eureka!, a Dutch scientific magazine did an [[http://www.physics.leidenuniv.nl/eureka/pdf-magazines/eureka20.pdf|article on Globe4D]] which is now available as PDF. Two pages about our four-dimensional globe with detailed information about how it all started and about our future plans.



==== Carribean Cinekid ====
[[:Cinekid]] (The Netherlands) and [[:The Back Lot]] (Suriname) organize a film and new media festival in Paramaribo, [[:Suriname]]. [[:Globe4D]] will be there as part of the festival from April 3rd till 6th.

==== Surfspot TV ====
( http://www.globe4d.com/wp-content/uploads/2008/03/surfspot.png|Globe4D at SurfspotTV)During [[http://www.magevents.nl/ipon|IPON 2008]], APS IT-diensten from The Netherlands did a documentary on the fair for SurfspotTV with a nice item about Globe4D. It's online available now at [[http://v3.quadiatv.com/pres/|Surfspot TV]] or as [[http://portal.quadia.nl/template/podcast/SurfJournaal/Surf_Journaal3.m4v|video podcast]].




==== Innovaction Fair, Italy ====
[[:Globe4D]] has been exhibited at [[:InnovAction]], [[:Italy]] in February. The third InnovAction Fair of Knowledge, Ideas and Innovation was a big success. In total 45,000 visitors attended the fair and thousands of them got to play and learn from one of the four currently existing Globe4D models.



==== Museum for Natural history in Maastricht ====
Since February, one of our [[:Globe4D]] models is on permanent display in Maastricht in The Netherlands. First as part of the China Dino exhibition in [[:Centre Céramique]]. After April as part of the collection of the [[:Museum for Natural History in Maastricht]].

(http://www.globe4d.com/wp-content/uploads/2008/03/chinadino.jpg|Globe4D at China Dino in Maastricht)

(tag>Globe4D)


~~DISCUSSION~~
