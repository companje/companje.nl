---
title: 
---
Van 19 t/m 23 maart zit ik samen met Dora en [[people:De Spullenmannen]] in Arhus in Denemarken om te spelen met twee gigantische Kuka's, mens-grote robots van het type die je op het plaatje ziet.

(blog:groeten-uit-arhus.jpg?550|Groeten uit Arhus)

<blockquote>We gaan daar met Mads Wahlberg werken aan een interactie met de Kuka robots die de Spullenmannen afgelopen najaar aan hem hebben overgedaan. Mads heeft in Aarhus een aantal technisch vaardige enthousiastelingen verzameld in een robot-clubje dat elke woensdagavond aan de robots sleutelt. Ze hebben inmiddels wat hardware gebakken die de servo-motoren van de robot direct kan aansturen en ook is het nu gelukt om de resolvers uit te lezen zodat er ook positie-data terug gestuurd kan worden. Dat betekent dat er een eigen robot-sturing gebouwd kan gaan worden die live is bij te sturen waardoor er een interessante real-time interactie mogelijk wordt.

Het plan is nu om op donderdag 20 en vrijdag 21 maart te proberen deze sturing te koppelen aan een visie-systeem dat Diana zal programmeren. Het voornaamste doel van deze sessie is om het principe aan te tonen zodat we daar weer verder op kunnen bouwen en om te onderzoeken hoe de samenwerking bevalt met het oog op een mogelijke coproductie volgend jaar. Technisch gezien is de missie geslaagd als we tenminste één robot-as direct op een camerabeeld kunnen laten reageren. ([[http://www.spullenmannen.nl]])</blockquote>

Update: 27-3-2008
Harmen: Very nice meeting you last week. We were very inspired by it and enjoyed working together, and were especially excited to see the kuka responding to live video in the end. Looking forward to working together again.
Maybe we should just start planning for a follow up workshop. Let's keep an eye open for opportunities to gather and jump into the pressure cooker again. As for us, we are quite flexible when it comes to planning...
You can find the robot wiki at http://www.companje.nl/robotclub/ Take a look and add links, documentation, code, video as you like. We will add some after this weekend as we are now working to get the Jukebus rocking and rolling for her maiden trip to a nearby festival coming saturday.
Thanks again for last week, and see you all soon,

Wiki for the robot club: [[http://www.companje.nl/robotclub/|Robotclub Wiki]]


===== Movie of our experiments =====
(youtube>large:jM7crZU6kyM)

===== More info =====
On the Robotclub Wiki I wrote down some info about how to communicate with the [[http://www.companje.nl/robotclub/doku.php?id=scorbot_er-v_plus|Scorbot ER-V Plus with Processing or C++]].



(tag>Robots Tech Art Electronics)

~~DISCUSSION~~
