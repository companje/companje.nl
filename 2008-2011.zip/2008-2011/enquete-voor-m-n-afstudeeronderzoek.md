---
title: 
---
(  :blog:2009:01:globe4d-img_0584.jpg?250|Globe4D)Voor m'n afstudeeronderzoek heb ik jullie hulp nodig. Ik heb een enquete opgesteld die in kaart moet brengen waar wetenschappers behoefte hebben als het om Globe4D gaat. Ik wil gaan onderzoeken wat er aan Globe4D moet veranderen wil je er wetenschappelijk onderzoek mee kunnen doen, dat wil zeggen Globe4D gebruiken om wetenschappelijke data mee te analyseren. Dus niet zozeer meer het overdragen van wetenschappelijke resultaten aan een groot publiek zoals we dat nu doen, maar ik ga kijken hoe Globe4D ingezet kan worden als wetenschappelijk instrument.

De enquete staat [[http://survey.globe4d.com|hier]], is in het Engels maar je mag 'm in het Nederlands invullen als je wilt. Voel je vrij om vragen over te slaan waar je niks mee kunt.

Alvast bedankt!

http://survey.globe4d.com

(tag>Study Globe4D)


~~DISCUSSION~~
