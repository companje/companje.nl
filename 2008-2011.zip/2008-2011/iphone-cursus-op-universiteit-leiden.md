---
title: iPhone cursus op Universiteit Leiden
---
//Het loopt storm voor iPhone-cursus//
\
\
Er is een overweldigende belangstelling voor gratis cursus programmeren voor de iPhone die het informatica-instuut LIACS aanbiedt.

‘Er zijn inmiddels vierhonderd aanmeldingen’ vertelt onderwijscoördinator Annebeth Simonsz van de master Media Technology. ‘Ik had een zaal gereserveerd bij Sociale Wetenschappen waar honderd man in passen, dus ik ben hard op zoek naar extra ruimte.’

Het LIACS biedt een cursus aan van twee vrijdagmiddagen en week huiswerk, waarin de deelnemers kunnen leren om programmaatjes te schrijven voor Apples gadget-telefoon met bewegingsdetector en touchscreen. De docenten zijn Media Technology-alumnus **Rick Companje en professor Bas Haring**. Deelnemers hoeven geen iPhone te hebben, maar moeten wel kunnen programmeren.

Simonsz: ‘In de flyer staat dat we de voorkeur geven aan studenten en scholieren, dus we zullen straks moeten selecteren. Die vierhonderd mensen zijn vooral studenten van universiteit en HBO, maar ook scholieren. Daarnaast zijn het mensen uit de omgeving met kleine bedrijfjes, of gewoon belangstellenden. Die laatste groep wil je eigenlijk ook bedienen, maar het gaat gewoon niet. We zijn nog aan het overwegen of we de cursus later nog een keer gaan geven of dat het bij een eenmalige actie blijft.’ BB

(tag>Tech Study Teaching)


~~DISCUSSION~~
