---
title: Fluxlezing kunst en wetenschap door de Spullenmannen
---
(  :blog:fluxlezing200.jpg)

Nieuwsgierigheid is de gezamenlijke drijfveer van kunstenaars en wetenschappers. En de beste manier om deze nieuwsgierigheid te bevredigen is het doen van een experiment. De Spullenmannen vertellen in deze fluxlezing hoe ze een brug slaan tussen kunst en wetenschap en hoe met oude apparaten de wetten der natuur ontrafeld kunnen worden.

De Spullenmannen is een kunstenaarscollectief uit Amersfoort. Ze maken theater, installaties, beeldende kunst en doen uitvindingen-waar-niemand-op-zit-te-wachten.

Dinsdag 13 april 2010
17.00 uur
Auditorium (lokaal 2009)
www.spullenmannen.nl 

(:blog:flux-13-april-usat.pdf|Meer info PDF)

(tag>Events Art Tech Science Math Museums Study)


~~DISCUSSION~~
