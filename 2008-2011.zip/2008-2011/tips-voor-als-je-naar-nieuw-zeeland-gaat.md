---
title: Tips voor als je naar Nieuw Zeeland gaat
---
Omdat [[http://downunder.sylvain.nl|Sylvain en Saskia]] momenteel in Australie en straks Nieuw Zeeland zijn en ze mij vroegen om wat tips omdat de buurt er een beetje ken heb ik een lijstje gemaakt met must-see's op het noorder en zuidereiland van Nieuw Zeeland:



=====Noorder eiland=====
*Rotorua
**zorben
**stinkende modderpoelen ga vooral naar Waiotapu
**ga zwemmen in de Kerozine Creek, een warm water snelstromend riviertje
*Taupo
**parachutte springen
**evt bungy jumpen
**Huka Falls * erg indrukwekkende waterval
**natuurlijk warmwater stroompje in de rivier van Taupo . Erg leuk om even in te baden tijdens/na de korte leuke Huka Falls track wandeling die langs de rivier loopt. 
*Tongariro National Park, met Mount Doom enzo  
**Tongariro Crossing: erg mooie (lekker pittige) dagwandeling die kun je boeken bij de iSite (VVV) in Taupo. Je kunt er ook wel met eigen vervoer gratis naartoe denk ik.
*gave duinen helemaal in het noorden van Northland (alles boven auckland) en een strand (99mile beach) waar je over kunt rijden met de auto maar vast niet met een huurauto of stiekem toch.
*mooie grote Kauri en Totara bomen ergens in Whangarei,
*Wellington, hoofdstad. Te Papa museum is wel leuk.
*(bijna) Meest oostelijke plek van de wereld is een vuurtoren East Cape.
*Coromandel - mooi gebied aan de oostkant van het noorder eiland met een mooi strand met warm water in de grond als het eb is in Hahei en mooie tweedaagse wandeling (Pinnacles track) met overnachting in Coromandel National Park.
*Mount Egmond of Taranaki in New Plymouth is een mooie berg als het mooi weer is. Als het slecht weer is heb je er niks te zoeken.
=====Zuider eiland=====
* Lekker Kanoeen met een gids in Abel Tasman national park
* Grotten in Greymouth
* Fox Glacier
* Bioscoop in Wanaka
* Jetboaten en Raften in Queenstown
* Caples en Greenstone track. 3 daagse wandeling en slapen in hutten. Erge aanrader als je 3 pittige dagen wilt lopen door hele mooie natuur.
* Milford Sound * schijnt een erg mooie wandeling te zijn. moet je HEEL ver van te voren boeken. Misschien nu al wel.
* Dunedin is een studentenstad. Niet zo veel te beleven. O ja, wel Pinguins en Albatrossen op het schiereiland.
* Christchurch is een behoorlijk grote stad voor NZ begrippen. Toch niet zo veel te beleven.
* Arthurs Pass is een mooie wandeling
* Mount Cook is een mooie berg.
* Kaikoura, kun je op een boot Walwissen bekijken en met dolfijnen zwemmen. Heb ik niet gedaan. Schijnt leuk te zijn.
* Queen Charlotte Track in Picton - (niet zo'n zware) wandeling door de fjorden. 3 dagen met super goed verzorgde overnachtingen. Te boeken bij het hele leuke 'The Villa' hostel in Picton.

Meer tips in mijn boek met reisverhalen uit Nieuw Zeeland: [[http://companje.nl/boek.pdf|Kiwi's en Autowrakken]]


(tag>Travel)

~~DISCUSSION~~
