---
title: Video experiment Benjolin
---
Sinds vandaag is de kabel afgesloten... niet dat ik 'm ooit officieel had laten aansluiten maar ik had eerst wel zenders en nu alleen sneeuw. Daarom moet ik nu maar andere dingetjes met m'n "TV" doen zoals freaken met m'n [[http://web.me.com/klangbureau/DIY/Benjolin.html|Benjolin]].
\
<html><object width="500" height="280" ><param name="allowfullscreen" value="true" /><param name="movie" value="http://www.facebook.com/v/10150176292552265" /><embed src="http://www.facebook.com/v/10150176292552265" type="application/x-shockwave-flash" allowfullscreen="true" width="500" height="280"></embed></object></html>


(tag>Tech Art Projects Fun)


~~DISCUSSION~~
