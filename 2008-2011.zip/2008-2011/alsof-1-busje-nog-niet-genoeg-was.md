---
title: Alsof 1 busje nog niet genoeg was...
---
Inmiddels is het twee maanden geleden dat ik m'n witte Renault Estafette kampeerbusje kocht en die staat al sindsdien bij de garage... de remmen... Niet zo fijn dus. Het escaleert volledig uit de hand... De zomer is nog net niet voorbij en daarom heb ik maar een nieuwe gekocht, zodat ik in ieder geval weer een beetje blijer wordt. Nu heb ik dus twee busjes. 'Hebben' is een groot woord. Ik ben eigenaar van twee busjes. Ben benieuwd wanneer ik m'n witte terug krijg. Morgen neem ik de trein naar Maastricht. Daar haal ik de blauwe op. Daar reis ik meteen mee door naar Twente waar ik 'm aan m'n ouders ga laten zien. Eigenlijk vind ik wel dat ik eerst langs Utrecht moet om 'm vol te laden met Rick-spulletjes zoals Pong spelcomputers en retro-gordijntjes enzo maar dat komt nog wel. 
\
(blog:renaultestafette.jpg?550|)

(tag>Travel Fun)


~~DISCUSSION~~
