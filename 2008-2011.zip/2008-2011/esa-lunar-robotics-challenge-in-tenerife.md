---
title: ESA Lunar Robotics Challenge in Tenerife
---
Vorige week was ik een dagje naar Tenerife om de ESA uitgeschreven wedstrijd voor maan robotjes te filmen met de stereoscopische camera waar ik in opdracht van Cosine Research 2 dagen per week aan werk intern bij ESA. Erg gaaf! 
\
[[http://www.esa.int/esaHS/SEMTOH4KXMF_index_0.html|(http://www.esa.int/images/3dcamera_large,0.png)]]
\
Lees het [[http://www.esa.int/esaHS/SEMTOH4KXMF_index_0.html|nieuwsbericht op de ESA website]].

(tag>Tech Projects 3D)


~~DISCUSSION~~
