---
title: Graduation...
---
[[http://maartenlamers.com/rick-vs-danica/|(  http://maartenlamers.com/rick-vs-danica/boxingposter2.jpg?150)]]Dit bericht schijnt rond te gaan in de Media Technology mailgangen...

<blockquote>
Hi everyone,
\
Did you know that Rick and Danica are going to finish school in 2009!!!!
And Maarten Lamers made a contest out of it.
You really have to follow this site, its hilarious!
\
[[http://maartenlamers.com/rick-vs-danica/]]  
\
gr Joey</blockquote>


(tag>fun afstuderen study)


~~DISCUSSION~~
