---
title: Twee fijne Flash / Flex events in aantocht
---
Op 25 januari 2008 kun je me tegen komen op de eerste [[http://www.adobeusergroup.nl/2007/12/15/17-januari-2008-special-pre-release-meeting|Adobe Usergroup meeting]] van 2008 waar Flex, AIR en BlazeDS ge-pre-released worden en een maandje later van 24 t/m 26 februari op [[http://www.fitc.ca/|FITC Amsterdam 2008]].

[[http://www.adobeusergroup.nl/2007/12/15/17-januari-2008-special-pre-release-meeting|(blog:adobe-usergroup.png?550|Adobe Usergroup meeting)]]

[[http://www.fitc.ca/|(blog:fitc-amsterdam-2008.png?550|FITC Amsterdam 2008)]]

(tag>Flex Flash Events)


~~DISCUSSION~~
