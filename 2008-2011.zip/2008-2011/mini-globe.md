---
title: Mini Globe
---
I have been working on a mini globe last week as an input device while I'm developing the new [[:Globe4D]] software. It's using two highspeed laser mice in an angle of 90 degrees with each other. Currently I'm working  at an auto calibration function to recognize the different mouse devices, their speed and their angle with the projector. I'm almost there.
\
(blog:miniglobe1024.jpg?550|)

**Second version**  
(blog:2008:05:globe4d-mini-globe.jpg?550|Mini Globe4D for testing purposes)


(tag>Globe4D Tech Experiments)

~~DISCUSSION~~
