---
title: Koninginnenacht 2010 Utrecht
---
Op 29 april 2010 stond ik met een oude koffer met lege melkpakken portemonneetjes te maken op de vrijmarkt in Utrecht. Iedereen die een portemonneetje bij me kocht kreeg er een handleiding bij om ze vervolgens zelf ook te kunnen gaan maken. (Hilde bedankt voor het geweldige ontwerp van de handleiding!) De reacties van het publiek waren erg leuk. Ik hoop dat ik op deze manier een heleboel mensen heb aangezet om afval zelf te gaan hergebruiken.
\
(http://melkpakken.nl/melkpakportemonnee-foto-door-gitta-XL.jpg?550)
Foto door Gitta (alias Juffie)
(tag>Events Projects Ideas Fun)


~~DISCUSSION~~
