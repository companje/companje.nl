---
title: Waarom moeilijk doen?
---
Heerlijk dit... extreme nuchterheid. Een meisje, Ilona die aan haar docent Nederlands uitlegt waarom ze dat [[http://www.studentsonly.nl/uittreksels/bv.asp?BvID=601|uittreksel]] niet zelf heeft geschreven…

<blockquote>Ik heb dit boekje gekozen omdat u daar in de les al wat over had verteld. Niet alles natuurlijk, maar daarom heb ik het juist gekozen: ik wilde weten hoe het afliep.
Deze samenvatting heb ik van internet. Ik had hem natuurlijk ook zelf kunnen maken, maar ik denk niet dat hij dan heel erg anders was geweest. Dus waarom moeilijk doen?</blockquote>

(tag>Fun)


~~DISCUSSION~~
