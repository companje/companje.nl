---
title: SETUP in Utrecht
---
(  :blog:setup.jpg)[[http://www.setuputrecht|SETUP]] is a temporary nexus for anyone in Utrecht who is interested in the fusion of culture and technology.
\
It will be open for three months, from april till june, in 2010. It will be situated at the Neude square in Utrecht, the Netherlands.
\
SETUP is a pilotproject for the Medialab Utrecht foundation. This foundation aims to provide a permanent space for the Utrecht New Media Scene. SETUP is a part of their research phase.


(tag>)


~~DISCUSSION~~
