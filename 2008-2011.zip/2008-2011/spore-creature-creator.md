---
title: Spore Creature Creator
---
De Spore Creature Creator is verschenen als voorproefje op het lang verwachte computerspel van Will Wright dat de volledige geschiedenis en de toekomst van het leven simuleert.

<blockquote>Spore is op het eerste gezicht een evolutiegame, of een godgame. De speler reist langs vele generaties van een soort, en laat deze evolueren van een eencellig organisme tot een meer ingewikkeld wezen. Als het dan uiteindelijk intelligent genoeg is geworden, verandert het spel: de speler hoeft zich dan niet langer zorgen te maken over het uiterlijk en het karakter, maar ontwikkelt vanaf dat punt de beschaving van zijn diersoort. Op een zeker punt ontwikkelt de gemeenschap een UFO, waarmee de rest van het heelal verkend kan worden. Net zoals bij de meeste andere Maxis-games zijn er geen duidelijke doelstellingen, en is men vrij om te doen wat hij wil. Aldus Wright: 'Ik wilde de speler zich niet laten voelen zoals Luke Skywalker of Frodo Balings. Ik wil dat ze George Lucas en J.R.R. Tolkien zijn". [[http://nl.wikipedia.org/wiki/Spore_(computerspel)|wikipedia]]</blockquote>
(http://eu.spore.com/flash/nl/EA-Spore_Microsite_NL.swf?550x350)

(tag>Fun Games)

~~DISCUSSION~~
