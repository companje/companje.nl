---
title: The Things I See
---
Ik maak vaak screenshots. Als ik iets moois zie op een website of zelf iets goeds in elkaar hack dan maak ik daar een screenshot van. Die screenshots zouden eigenlijk automatisch geblogpost moeten worden. Net als de beelden van mijn scanner. Binnenkort op deze Wiki een autoblog op basis van mijn screenshots en scans.

Zie [[AutoBlog]]

(tag>Ideas)


~~DISCUSSION~~
