---
title: Nieuwe Globe4D animatie in ontwikkeling
---
Bij [[http://www.globe4d.com|Globe4D]] houden we continu bezig met het bedenken en maken van nieuwe interactieve animaties voor onze vier dimensionale wereldbol. Hieronder zie je een van onze meest recente interface schetsen: het trajact van het International Space Station. Standaard zie je waar het ruimtestation zich op dit moment bevindt, maar draai je aan de ring dan reis je een paar uur of paar dagen terug in de tijd. Of juist vooruit zodat precies kunt zien wat de eerst volgende keer is dat het space station boven je huis langs vliegt.   
\
(:blog:globe4d-international-space-station-iss.jpg?500|Volg het International Space Station (ISS) op Globe4D)

(tag>Globe4D ESA Space)


~~DISCUSSION~~
