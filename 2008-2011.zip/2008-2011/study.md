---
title: Study
---
<blockquote>The Media Technology MSc programme is a place where students are encouraged to formulate their own scientific questions, and to translate personal inspirations and curiosities into their own research projects. To answer these questions, students create actual products, because we are convinced that by doing and creating, new scientific insights into the underlying question are encountered.

The programme is a joint initiative of Leiden University’s computer science institute (LIACS) and the Faculty of Creative and Performing Arts.</blockquote>

*[[http://mediatechnology.leiden.edu/|Media Technology website]]

====== Links to this page ======
(backlinks>.)
