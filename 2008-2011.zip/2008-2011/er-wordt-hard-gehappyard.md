---
title: Er wordt hard gehappyard
---
Hier in LOODS 6 op het Amsterdamse KNSM eiland wordt momenteel hard door ons gehappyard. Dinsdag a.s. is deadline van de demo van deze mobiele game die we voor Japan aan het ontwikkelen zijn.
 
Update 22-4-2008: De uitslag is bekend. We zijn 2e geworden met Happyard.

(blog:happyard-foto.jpg?550|Happyard)

(tag>Projects)

~~DISCUSSION~~
