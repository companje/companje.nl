---
title: Simple password holds the key
---
(afstuderen:bbc-news-2002-simple-password-holds-the-key.pdf|BBC News (2002) - Simple password holds the key)

===== Summary =====
*Reidar Djupedal took to the grave the password he had chosen for the electronic archive of books and documents.
*But it only took hackers five hours to crack the code and unlock the valuable archive.
*name spelt backwards.
*It would have taken the institute about four years of work to recreate the catalogue had they failed to find the password.
